#-*- coding: utf-8 -*-



from stalker.core.models import entity






########################################################################
class Sequence(entity.StatusedEntity):
    """the sequence class
    """
    
    pass
