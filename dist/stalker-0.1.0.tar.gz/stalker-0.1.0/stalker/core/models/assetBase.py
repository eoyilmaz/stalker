#-*- coding: utf-8 -*-



from stalker.core.models import entity






########################################################################
class AssetBase(entity.StatusedEntity):
    """This is the base class for Shot and Asset classes.
    """
    
    
    
    pass

