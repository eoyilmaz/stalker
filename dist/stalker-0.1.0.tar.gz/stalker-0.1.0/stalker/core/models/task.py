#-*- coding: utf-8 -*-



from stalker.core.models import entity






########################################################################
class Task(entity.StatusedEntity):
    """the task class
    """
    
    pass
