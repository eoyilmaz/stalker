#-*- coding: utf-8 -*-



from stalker.core.models import entity






########################################################################
class Version(entity.StatusedEntity):
    """The Version class is the connection of Assets to versions of that asset.
    So it connects the Assets to file system, and manages the files as
    versions.
    """
    
    
    
    pass

