#-*- coding: utf-8 -*-



from stalker.core.models import entity






########################################################################
class Group(entity.Entity):
    """the group class
    """
    
    pass
