#-*- coding: utf-8 -*-



from stalker.core.models import assetBase






########################################################################
class Shot(assetBase.AssetBase):
    """The Shot class to manage Shot data.
    """
    
    
    
    pass

