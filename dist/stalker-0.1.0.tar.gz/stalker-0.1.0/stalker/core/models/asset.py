#-*- coding: utf-8 -*-



from stalker.core.models import assetBase






########################################################################
class Asset(assetBase.AssetBase):
    """The Asset class is the whole idea behind Stalker.
    """
    
    
    
    pass

