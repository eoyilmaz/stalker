#-*- coding: utf-8 -*-



from stalker.core.models import entity






########################################################################
class Project(entity.StatusedEntity):
    """the project class
    """
    
    pass
