#-*- coding: utf-8 -*-



from stalker.core.models import entity






########################################################################
class Booking(entity.Entity):
    """Booking holds the information about when a user done which task and
    spend how many hours on doing that task.
    """
    
    
    
    pass
