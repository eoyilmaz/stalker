#-*- coding: utf-8 -*-
"""
Stalker is an asset and resource management system, designed for animation and
vfx studios. See docs for more information.
"""



__version__ = "0.1.0.20110110"
