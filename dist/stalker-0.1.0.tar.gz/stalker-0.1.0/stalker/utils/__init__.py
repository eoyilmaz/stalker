#-*- coding: utf-8 -*-
"""This contains little utility functions, like string conditioning etc.
"""
