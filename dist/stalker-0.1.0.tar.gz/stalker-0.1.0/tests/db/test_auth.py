#from stalker.db import auth

#@auth.login_required
#def test_func( input1, input2):
    #print "inside the original func"
    #print input1, input2
    #print "original function ended"

#test_func("ozgur", "yilmaz")



#########################################################################
#class AClass(object):
    #"""for testing methods requiring login
    #"""
    
    ##----------------------------------------------------------------------
    #def __init__(self, value1, value2):
        
        #self._value1 = value1
        #self._value2 = value2
    
    
    
    ##----------------------------------------------------------------------
    #@auth.login_required
    #def calculate(self, value1, value2):
        #print "inside class method"
        #print value1, value2
        #print "ended class method"
    


#a_class_inst = AClass("ozgur", "yilmaz")

#a_class_inst.calculate("ozgur2", "yilmaz2")

