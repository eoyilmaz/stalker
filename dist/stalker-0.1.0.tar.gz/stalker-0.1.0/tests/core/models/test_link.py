#-*- coding: utf-8 -*-




import mocker







########################################################################
class LinkTester(mocker.MockerTestCase):
    """tests the :class:`~stalker.core.models.link.Link` class
    """
    
    
    #----------------------------------------------------------------------
    def setUp(self):
        """setup the test 
        """
        
        self.fail("test is not implemented yet")

