<!-- Tufts VUE 3.0.2 concept-map (stalker_design.vue) 2011-01-09 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/usr/share/vue/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Sun Jan 09 00:22:11 EET 2011 by ozgur on platform Linux 2.6.35-24-generic in JVM 1.6.0_22-b04 -->
<!-- Do Not Remove: Saving version @(#)VUE: built July 1 2010 at 1436 by vue on Linux 2.4.21-57.EL i386 JVM 1.5.0_06-b05(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0"
    label="stalker_design.vue" created="0" x="0.0" y="0.0"
    width="4290.8525" height="4686.808" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1294525331441" size="461293"
        spec="/home/ozgur/Documents/development/stalker/docs/source/_static/stalker_design.vue"
        type="1" xsi:type="URLResource">
        <title>stalker_design.vue</title>
        <property key="File" value="/home/ozgur/Documents/development/stalker/docs/source/_static/stalker_design.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <metadata-list category-list-size="1" other-list-size="0"
        ontology-list-size="0" RCategoryListSize="0">
        <ontology-list-string></ontology-list-string>
        <metadata xsi:type="vue-metadata-element">
            <value></value>
            <key>http://vue.tufts.edu/vue.rdfs#none</key>
            <type>1</type>
        </metadata>
    </metadata-list>
    <URIString>http://vue.tufts.edu/rdf/resource/5d104b14c00007d601b277f03c449819</URIString>
    <child ID="1292" label="StatusedEntity" layerID="1"
        created="1272407309190" x="10500.6045" y="1436.2256"
        width="177.0" height="127.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4164129c7f00010135ea5711c6b2b353</URIString>
        <child ID="1474" label="status | INTEGER"
            created="1277541451268" x="34.0" y="23.0" width="107.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#7F7F7F</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7367e4507f000101783f472bcaee1099</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1130" label="status_list | ONE | STATUSLIST"
            created="1272404328844" x="34.0" y="43.25" width="183.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#7F7F7F</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4137afe37f00010135ea5711bcd42ca9</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1161" label="notes | MANY | NOTE"
            created="1272404853014" x="34.0" y="63.5" width="125.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4140ccdb7f00010135ea57110e2be72a</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1128" label="thumbnail | ONE | FILE"
            created="1272404328842" x="34.0" y="83.75" width="135.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4137afd27f00010135ea5711ec68f281</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1992" label="references | MANY | LINK"
            created="1289269306299" x="34.0" y="104.0" width="147.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/2e718e687f0001010115c6cb04b3215f</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1088" label="AssetBase" layerID="1"
        created="1272403764881" x="10288.63" y="1916.0773" width="148.5"
        height="66.5" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4137afd47f00010135ea5711d86d98a9</URIString>
        <child ID="1510" label="type | ONE | ASSETTYPE"
            created="1277558085544" x="34.0" y="23.0" width="145.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/746640437f0001014a6b2ab74d53f206</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1441" label="tasks | MANY | TASK"
            created="1277506807868" x="34.0" y="43.25" width="121.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/715782ba7f0001010a53046185813dc0</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1091" label="Message" layerID="1" created="1272403945846"
        x="11549.448" y="1916.0773" width="156.75" height="188.0"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4137afd57f00010135ea5711a389d746</URIString>
        <child ID="1094" label="attachments | UNICODE"
            created="1272403951530" x="34.0" y="23.0" width="144.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4137afd67f00010135ea5711b95a4d7f</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1112" label="to | MANY | USER"
            created="1272404214542" x="34.0" y="43.25" width="105.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4137afdb7f00010135ea5711e7456541</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1101" label="cc | MANY | USER"
            created="1272404093454" x="34.0" y="63.5" width="107.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4137afd87f00010135ea571115431953</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1110" label="subject | UNICODE"
            created="1272404197822" x="34.0" y="83.75" width="116.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4137afdb7f00010135ea571132d59790</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1098" label="body | UNICODE" created="1272404061830"
            x="34.0" y="104.0" width="102.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4137afd77f00010135ea57113a506442</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1116" label="replies | MANY | MESSAGE"
            created="1272404237182" x="34.0" y="124.25" width="156.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4137afdc7f00010135ea5711f44caca7</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1994" label="reply_to | ONE | MESSAGE"
            created="1289270202512" x="34.0" y="144.5" width="155.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/2e7ee83f7f0001010115c6cb1bbf061f</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1556" label="note_for | MANY | ENTITY"
            created="1279317596814" x="34.0" y="164.75" width="147.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#DAA9FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/dd4612627f0001010c4cdf7ed632dac8</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1131" layerID="1" created="1272404424409" x="10588.635"
        y="1563.5" width="1039.4326" height="353.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4137afe67f00010135ea57113e9099fb</URIString>
        <point1 x="10589.135" y="1564.0"/>
        <point2 x="11627.567" y="1916.0"/>
        <ID1 xsi:type="node">1292</ID1>
        <ID2 xsi:type="node">1091</ID2>
        <ctrlPoint0 x="10589.293" y="1888.0895" xsi:type="point"/>
        <ctrlPoint1 x="11627.313" y="1822.4156" xsi:type="point"/>
    </child>
    <child ID="1145" label="Link" layerID="1" created="1272404675030"
        x="11623.194" y="796.225" width="140.25" height="66.5"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4140cd037f00010135ea57112130f8c4</URIString>
        <child ID="1147" label="url | UNICODE" created="1272404693670"
            x="34.0" y="23.0" width="90.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4140cd037f00010135ea57117ab47786</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2420" label="type | ONE | LINKTYPE"
            created="1294297640237" x="34.0" y="43.25" width="134.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/5a274e517f000101223c8087a13d64dd</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1157" label="Playlist" layerID="1"
        created="1272404832018" x="10708.462" y="1436.2256"
        width="123.0" height="46.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4140cd0a7f00010135ea571155c75028</URIString>
        <child ID="1160" label="files | MANY | LINK"
            created="1272404845966" x="34.0" y="23.0" width="111.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4140cd0b7f00010135ea5711602370dd</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1166" label="Project" layerID="1" created="1272404937838"
        x="9876.218" y="1916.0773" width="201.75" height="289.25"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4140cd0d7f00010135ea5711f07153c7</URIString>
        <child ID="1169" label="start | DATETIME"
            created="1272404960922" x="34.0" y="23.0" width="102.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4140cd0f7f00010135ea57110c840b19</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1168" label="due | DATETIME" created="1272404953162"
            x="34.0" y="43.25" width="99.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4140cd0e7f00010135ea5711db2dd864</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1520" label="assets | MANY | ASSET"
            created="1277849783149" x="34.0" y="63.5" width="137.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/85ca6d117f0001010cdfa65c929e6a1b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1506" label="sequences | MANY | SEQUENCE"
            created="1277546655591" x="34.0" y="83.75" width="191.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/73b722e97f000101783f472b90b90716</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1171" label="users | MANY | USER"
            created="1272404979390" x="34.0" y="104.0" width="127.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4140cd107f00010135ea57114a508f5b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1799" label="image_format | ONE | IMAGEFORMAT"
            created="1279573849214" x="34.0" y="124.25" width="216.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/ec8bebda7f0001010147e4f04ea33efd</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1423" label="fps | FLOAT" created="1277505694849"
            x="34.0" y="144.5" width="74.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7146b48d7f0001010a530461cc109033</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1962" label="display_width | FLOAT"
            created="1289153600481" x="34.0" y="164.75" width="132.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/278b9a9a7f000101775978e75d5e32b6</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2011" label="is_stereoscopic | BOOL"
            created="1290254126593" x="34.0" y="185.0" width="141.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/6924820d7f00010168376cc3eaa57d6b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2007" label="structure | ONE | STRUCTURE"
            created="1289689925944" x="34.0" y="205.25" width="178.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/47830e6e7f0001015a3184d85f950ed5</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2195" label="repository | ONE | REPOSITORY"
            created="1290434059609" x="34.0" y="225.5" width="186.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/73dd535d7f0001010b45ad3dcc59d99c</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2221" label="lead | ONE | USER"
            created="1291042857476" x="34.0" y="245.75" width="113.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/98294d057f000101247aa859e3c11b58</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2416" label="type | ONE | PROJECTTYPE"
            created="1294182301176" x="34.0" y="266.0" width="163.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/53470d807f0001011583c12d10e333f6</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1175" layerID="1" created="1272405036671" x="9976.029"
        y="1562.5" width="613.6465" height="354.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4140cd177f00010135ea57116fb443d5</URIString>
        <point1 x="10589.176" y="1563.0"/>
        <point2 x="9976.529" y="1916.0"/>
        <ID1 xsi:type="node">1292</ID1>
        <ID2 xsi:type="node">1166</ID2>
        <ctrlPoint0 x="10589.544" y="1888.7561" xsi:type="point"/>
        <ctrlPoint1 x="9976.257" y="1845.9941" xsi:type="point"/>
    </child>
    <child ID="1176" label="Sequence" layerID="1"
        created="1272405154343" x="10107.741" y="1916.0773"
        width="150.75" height="188.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4144a3f27f00010135ea57117ebd1aac</URIString>
        <child ID="1436" label="project | ONE | PROJECT"
            created="1277506573169" x="34.0" y="23.0" width="148.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7153ccd27f0001010a53046130064ba9</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1182" label="shots | MANY | SHOT"
            created="1272405273586" x="34.0" y="43.25" width="125.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4144a3f47f00010135ea57118b03d3ed</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1529" label="lead | ONE | USER"
            created="1277850590443" x="34.0" y="63.5" width="113.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/85d509547f0001010cdfa65c7240076e</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1885" label="start | DATETIME"
            created="1288255825480" x="34.0" y="83.75" width="102.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f2086a687f0001010d9438de9871e006</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1179" label="due | DATETIME" created="1272405239826"
            x="34.0" y="104.0" width="99.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4144a3f37f00010135ea5711de3f8ed2</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2008" label="offline | LINK" created="1289702947670"
            x="34.0" y="124.25" width="80.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/484975a57f0001015a3184d81211a0d2</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2010" label="stoaryboard | LINK"
            created="1289703052278" x="34.0" y="144.5" width="112.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/484b00917f0001015a3184d88131b25d</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1177" label="assets | shots -> assets"
            created="1272405161918" x="34.0" y="164.75" width="144.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#BDE5F2</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4144a3f27f00010135ea571169e0a9c3</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1184" layerID="1" created="1272405314984" x="10181.338"
        y="1563.0" width="408.3623" height="353.5625" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4144a3f57f00010135ea5711d8e41568</URIString>
        <point1 x="10589.2" y="1563.5"/>
        <point2 x="10181.838" y="1916.0625"/>
        <ID1 xsi:type="node">1292</ID1>
        <ID2 xsi:type="node">1176</ID2>
        <ctrlPoint0 x="10589.69" y="1889.3875" xsi:type="point"/>
        <ctrlPoint1 x="10180.805" y="1840.0104" xsi:type="point"/>
    </child>
    <child ID="1185" label="Shot" layerID="1" created="1272405338854"
        x="10050.475" y="2275.6968" width="175.5" height="208.25"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/414f1a427f00010135ea57117bdc53d1</URIString>
        <child ID="1519" label="sequence | ONE | SEQUENCE"
            created="1277849616279" x="34.0" y="23.0" width="178.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/85ca6d1d7f0001010cdfa65c7007b57b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1523" label="assets | MANY | ASSET"
            created="1277850245048" x="34.0" y="43.25" width="137.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/85cf63147f0001010cdfa65c4ada3097</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1187" label="cut_duration | INTEGER"
            created="1272405350634" x="34.0" y="63.5" width="141.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/414f1a427f00010135ea57111b10b68c</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1188" label="cut_in | INTEGER"
            created="1272405364822" x="34.0" y="83.75" width="106.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/414f1a427f00010135ea5711fda03f80</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1190" label="cut_out | INTEGER"
            created="1272405378378" x="34.0" y="104.0" width="113.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/414f1a437f00010135ea57113c08fcf5</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2009" label="online | LINK" created="1289702971599"
            x="34.0" y="124.25" width="81.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4849e7047f0001015a3184d87c51e040</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1960" label="inter_axial_distance | FLOAT"
            created="1289153571666" x="34.0" y="144.5" width="167.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/278b9ab27f000101775978e70bad0084</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1961" label="convergence_distance | FLOAT"
            created="1289153587186" x="34.0" y="164.75" width="181.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/278b9ab37f000101775978e7a0658db2</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2006" label="project | sequence -> project"
            created="1289688952231" x="34.0" y="185.0" width="166.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#BDE5F2</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4773e6b17f0001015a3184d876814997</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1204" layerID="1" created="1272406020260" x="10136.918"
        y="1982.0" width="226.62598" height="294.25" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/414f1a447f00010135ea571162d9f880</URIString>
        <point1 x="10363.044" y="1982.5"/>
        <point2 x="10137.418" y="2275.75"/>
        <ID1 xsi:type="node">1088</ID1>
        <ID2 xsi:type="node">1185</ID2>
        <ctrlPoint0 x="10363.838" y="2142.7844" xsi:type="point"/>
        <ctrlPoint1 x="10136.637" y="2174.8655" xsi:type="point"/>
    </child>
    <child ID="1205" label="Task" layerID="1" created="1272406042962"
        x="10466.298" y="1916.0773" width="246.0" height="370.25"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4156061a7f00010135ea5711dcb8f75c</URIString>
        <child ID="1795" label="priority | INTEGER"
            created="1279319036406" x="34.0" y="23.0" width="109.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/dd5bc86d7f0001010c4cdf7ed67689ed</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1206" label="resource | ONE | USER"
            created="1272406057074" x="34.0" y="43.25" width="138.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061a7f00010135ea57115fceb210</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1207" label="bid | TIMEDURATION"
            created="1272406067372" x="34.0" y="63.5" width="126.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061a7f00010135ea57114dad0daf</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1379" label="effort | TIMEDURATION"
            created="1277499479767" x="34.0" y="83.75" width="136.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/70eb8f3e7f0001010a530461d9ea6efc</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1210" label="duration | TIMEDURATION"
            created="1272406078134" x="34.0" y="104.0" width="154.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061b7f00010135ea571157ac5234</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1394" label="depends | MANY | TASK"
            created="1277500447230" x="34.0" y="124.25" width="140.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/70f609097f0001010a5304612bb962ad</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1216" label="start | DATETIME"
            created="1272406138030" x="34.0" y="144.5" width="102.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061c7f00010135ea5711cd608471</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1211" label="end | DATETIME" created="1272406082814"
            x="34.0" y="164.75" width="99.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061b7f00010135ea571176f5fe67</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1393" label="percent_complete | INTEGER"
            created="1277500271357" x="34.0" y="185.0" width="172.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/70f471907f0001010a5304616138cda3</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1213" label="milestone | BOOL"
            created="1272406111786" x="34.0" y="205.25" width="108.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061c7f00010135ea5711df3cc9d5</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1214" label="pipeline_step | ONE | PIPELINE STEP"
            created="1272406123914" x="34.0" y="225.5" width="218.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061c7f00010135ea5711382a4fce</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1219" label="bookings | MANY | BOOKING"
            created="1272406178764" x="34.0" y="245.75" width="167.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061d7f00010135ea5711f78c3ffb</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1482" label="versions | MANY | VERSION"
            created="1277543180124" x="34.0" y="266.0" width="161.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/738287e27f000101783f472bbfb64909</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1525" label="published_versions | MANY | VERSION"
            created="1277850285557" x="34.0" y="286.25" width="223.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/85d09fcc7f0001010cdfa65c9b0d5367</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1551" label="parent_asset | ONE | ASSETBASE"
            created="1277851861819" x="34.0" y="306.5" width="197.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#DAA9FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/85e8439a7f0001010cdfa65c5fcb33e3</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1526"
            label="last_published_version | published_versions[-1]"
            created="1277850333863" x="34.0" y="326.75" width="275.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#BDE5F2</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/85d0f0437f0001010cdfa65c3ab63ddc</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1521" label="project | assetBase -> project"
            created="1277850062348" x="34.0" y="347.0" width="171.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#BDE5F2</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/85cf631c7f0001010cdfa65c51bb732f</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1220" layerID="1" created="1272406209511" x="10588.692"
        y="1563.5" width="1.6074219" height="353.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4156061d7f00010135ea5711c2172d7e</URIString>
        <point1 x="10589.192" y="1564.0"/>
        <point2 x="10589.8" y="1916.0"/>
        <ID1 xsi:type="node">1292</ID1>
        <ID2 xsi:type="node">1205</ID2>
        <ctrlPoint0 x="10589.643" y="1889.0906" xsi:type="point"/>
        <ctrlPoint1 x="10589.919" y="1872.0806" xsi:type="point"/>
    </child>
    <child ID="1227" label="Booking" layerID="1" created="1272406409370"
        x="10860.853" y="1436.2256" width="155.25" height="107.0"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4156061e7f00010135ea571114c0ee72</URIString>
        <child ID="1229" label="start_date | DATETIME"
            created="1272406418370" x="34.0" y="23.0" width="133.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061e7f00010135ea5711d63f3b4e</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1230" label="duration | TIMEDURATION"
            created="1272406425263" x="34.0" y="43.25" width="154.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061f7f00010135ea5711a6c1112f</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1231" label="task | ONE | TASK"
            created="1272406430066" x="34.0" y="63.5" width="108.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061f7f00010135ea57112dad9a44</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1232" label="resource | ONE | USER"
            created="1272406435518" x="34.0" y="83.75" width="138.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4156061f7f00010135ea57110e5bbdd2</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1235" label="User" layerID="1" created="1272406484302"
        x="9909.48" y="1436.2256" width="206.25" height="289.25"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/415b1bc47f00010135ea571102f905e6</URIString>
        <child ID="1237" label="email | UNICODE" created="1272406498598"
            x="34.0" y="23.0" width="107.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/415b1bc57f00010135ea5711bb1452df</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1243" label="login_name | UNICODE"
            created="1272406543618" x="34.0" y="43.25" width="142.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/415b1bc67f00010135ea5711cc5235aa</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1239" label="first_name | UNICODE"
            created="1272406514826" x="34.0" y="63.5" width="135.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/415b1bc57f00010135ea5711cecd2466</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1242" label="last_name | UNICODE"
            created="1272406537474" x="34.0" y="83.75" width="135.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/415b1bc67f00010135ea57114a0ec6bb</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1241" label="department | ONE | DEPARTMENT"
            created="1272406526891" x="34.0" y="104.0" width="199.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/415b1bc57f00010135ea5711df108926</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1245" label="password | UNICODE"
            created="1272406576770" x="34.0" y="124.25" width="131.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/415b1bc67f00010135ea57118ffe5686</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1246" label="permission_groups | MANY | GROUPS"
            created="1272406583326" x="34.0" y="144.5" width="222.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/415b1bc77f00010135ea57113656d812</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1442" label="tasks | MANY | TASK"
            created="1277507144415" x="34.0" y="164.75" width="121.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/715c39c47f0001010a53046192f39ef8</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1528" label="projects | MANY | PROJECT"
            created="1277850527948" x="34.0" y="185.0" width="161.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/85d3daed7f0001010cdfa65c1ca9c5be</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1530" label="sequences_lead | MANY | SEQUENCE"
            created="1277850633268" x="34.0" y="205.25" width="222.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#DAA9FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/85d5b47c7f0001010cdfa65ca49c356e</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2222" label="projects_lead| MANY | PROJECT"
            created="1291125082795" x="34.0" y="225.5" width="189.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#DAA9FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/9d0d965c7f0001015d73b35d3456f432</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2220" label="assets | tasks -> parent_assets"
            created="1291042704348" x="34.0" y="245.75" width="185.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#C6E8FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/982531327f000101247aa859a673b56a</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2370" label="last_login | DATETIME"
            created="1294054995724" x="34.0" y="266.0" width="132.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4bb089d87f000101283b96bbba818d63</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="1258" label="ShootTake" layerID="1"
        created="1272406937150" x="11043.6045" y="1916.0773"
        width="133.5" height="208.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FC938D</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/416412927f00010135ea5711ee89e7ec</URIString>
        <child ID="1262" label="first_frame" created="1272406965702"
            x="34.0" y="23.0" width="70.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/416412937f00010135ea5711e1bf0da0</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1263" label="frames_aspect_ratio"
            created="1272406971602" x="34.0" y="43.25" width="125.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/416412937f00010135ea5711025e4908</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1264" label="frames_have_slate"
            created="1272406979937" x="34.0" y="63.5" width="117.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/416412937f00010135ea571114f2487c</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1265" label="last_frame" created="1272406987082"
            x="34.0" y="83.75" width="70.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/416412947f00010135ea5711ba3432c6</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1266" label="link (entity)" created="1272406995742"
            x="34.0" y="104.0" width="69.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/416412947f00010135ea57119c4a005f</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1267" label="movie_aspect_ratio"
            created="1272407002554" x="34.0" y="124.25" width="119.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/416412947f00010135ea571193baeb10</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1268" label="movie_has_slate" created="1272407012830"
            x="34.0" y="144.5" width="106.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/416412947f00010135ea57111edef472</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1269" label="path_to_frames" created="1272407024178"
            x="34.0" y="164.75" width="98.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/416412947f00010135ea571180cf8f37</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1275" label="uploaded_movie" created="1272407065510"
            x="34.0" y="185.0" width="103.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/416412967f00010135ea5711e7b676e0</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1279" layerID="1" created="1272407119615" x="10588.688"
        y="1562.5" width="523.26465" height="354.125" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/416412967f00010135ea57116b7f484f</URIString>
        <point1 x="10589.188" y="1563.0"/>
        <point2 x="11111.453" y="1916.125"/>
        <ID1 xsi:type="node">1292</ID1>
        <ID2 xsi:type="node">1258</ID2>
        <ctrlPoint0 x="10589.623" y="1889.3555" xsi:type="point"/>
        <ctrlPoint1 x="11112.163" y="1848.8601" xsi:type="point"/>
    </child>
    <child ID="1284" label="PipelineStep" layerID="1"
        created="1272407197438" x="10646.452" y="796.225" width="154.0"
        height="262.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/4164129a7f00010135ea5711d22eff11</URIString>
        <child ID="1287" label="code | STRING" created="1272407213500"
            x="34.0" y="23.0" width="92.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4164129b7f00010135ea57112e40f6e2</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1507"
            label="Examples: design-DESIGN model-MODEL rig-RIG fur-FUR shading-SHADE previs-PREVIS match move-MM animation-ANIM fx-FX cloth sim-CLOTHSIM layout-LAYOUT lighting-LIGHT compositing-COMP"
            created="1277557969560" x="34.0" y="43.25" width="115.0"
            height="213.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7464cb477f0001014a6b2ab74e33abce</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Examples:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      design-DESIGN
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      model-MODEL
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      rig-RIG
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      fur-FUR
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      shading-SHADE
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      previs-PREVIS
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      match move-MM
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      animation-ANIM
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      fx-FX
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      cloth sim-CLOTHSIM
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      layout-LAYOUT
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      lighting-LIGHT
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      compositing-COMP
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Examples: design-DESIGN model-MODEL rig-RIG fur-FUR shading-SHADE previs-PREVIS match move-MM animation-ANIM fx-FX cloth sim-CLOTHSIM layout-LAYOUT lighting-LIGHT compositing-COMP</label>
        </child>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="1295" label="Tag" layerID="1" created="1272407402727"
        x="10323.469" y="577.8772" width="60.13867" height="36.2"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/41652daa7f00010135ea57110fc3ae1b</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="1299" label="Event" layerID="1" created="1272407465751"
        x="11972.512" y="796.225" width="159.0" height="147.5"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FC938D</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/41652dab7f00010135ea57113765e4bc</URIString>
        <child ID="1300" label="attribute_name | UNICODE"
            created="1272407733084" x="34.0" y="23.0" width="159.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/417945b37f00010135ea5711f7eb2636</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1302" label="event_type | INTEGER"
            created="1272407752888" x="34.0" y="43.25" width="131.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/417945b47f00010135ea5711afaf9d5a</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1304" label="link | ONE | ENTITY"
            created="1272407763884" x="34.0" y="63.5" width="115.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/417945b47f00010135ea57110de734c6</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1305" label="meta_data | UNICODE"
            created="1272407772990" x="34.0" y="83.75" width="135.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/417945b47f00010135ea57118bfc42a4</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1308" label="user | ONE | USER"
            created="1272407788218" x="34.0" y="104.0" width="114.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/417945b57f00010135ea5711d9b9080c</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1309" label="date_created | DATETIME"
            created="1272407797912" x="34.0" y="124.25" width="150.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/417945b57f00010135ea5711545ebf12</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1329" label="Department" layerID="1"
        created="1273399280163" x="10146.049" y="1436.2256"
        width="151.5" height="66.5" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7c845ab97f00010136a8a19945559ad8</URIString>
        <child ID="1331" label="members | MANY | USER"
            created="1273399329020" x="34.0" y="23.0" width="149.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7c845ab97f00010136a8a19938a35367</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2223" label="lead | ONE | USER"
            created="1291842810434" x="34.0" y="43.25" width="113.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/c7d533fd7f00010136536500f161e613</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="1337" layerID="1" created="1273535548147" x="10362.366"
        y="1562.5" width="227.31738" height="354.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/84a6a8077f00010170ca62f7da0e7b0d</URIString>
        <point1 x="10589.184" y="1563.0"/>
        <point2 x="10362.866" y="1916.0"/>
        <ID1 xsi:type="node">1292</ID1>
        <ID2 xsi:type="node">1088</ID2>
        <ctrlPoint0 x="10589.588" y="1889.2239" xsi:type="point"/>
        <ctrlPoint1 x="10362.838" y="1841.5029" xsi:type="point"/>
    </child>
    <child ID="1355" label="StatusList" layerID="1"
        created="1274041570267" x="10046.748" y="796.2019" width="156.0"
        height="46.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/a33b57e77f0001016609e5f078560790</URIString>
        <child ID="1395" label="statuses | MANY | STATUS"
            created="1277500691762" x="34.0" y="23.0" width="155.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/70f9fdd47f0001010a5304617b221190</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="1362" label="Version" layerID="1" created="1275345214941"
        x="10747.798" y="1916.0773" width="260.25" height="228.5"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f0822ba57f000101666558bbfaa1423c</URIString>
        <child ID="1363" label="is_published | BOOL"
            created="1275345214942" x="34.0" y="23.0" width="125.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f0822ba77f000101666558bb7043581b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1365" label="take | STRING, DEFAULT=MAIN"
            created="1275345214943" x="34.0" y="43.25" width="183.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f0822ba97f000101666558bbc49201a2</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1453" label="revision | INTEGER"
            created="1277507808575" x="34.0" y="63.5" width="116.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/716648fb7f0001010a530461590d8c55</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1452" label="version | INTEGER"
            created="1277507797831" x="34.0" y="83.75" width="113.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/716648fb7f0001010a530461d3a9c89a</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1456" label="review | MANY | COMMENT"
            created="1277507870809" x="34.0" y="104.0" width="156.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/71672ce27f0001010a530461f76d831f</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1939" label="sources | MANY | ASSETBASE"
            created="1288424048541" x="34.0" y="124.25" width="175.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/fc0f0e227f00010120d48785d51f8a9c</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1952" label="outputs | MANY | LINK"
            created="1288424286766" x="34.0" y="144.5" width="129.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/fc128cad7f00010120d48785781bf5c0</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1966" label="task | ONE | TASK"
            created="1289200707245" x="34.0" y="164.75" width="108.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#DAA9FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/2a5b1cab7f00010152380dbe0b735d44</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1967" label="asset | ONE | ASSETBASE"
            created="1289267559911" x="34.0" y="185.0" width="155.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#DAA9FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/2e56db847f0001010115c6cbc0fb456f</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2106"
            label="template | asset.project.templates[asset.type.name]"
            created="1290418741395" x="34.0" y="205.25" width="294.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#C6E8FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72f3a55b7f0001010b45ad3d8fd4b444</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1367" layerID="1" created="1275345268184" x="10588.673"
        y="1562.5" width="292.6211" height="354.0625" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f0822baa7f000101666558bbc8e3f079</URIString>
        <point1 x="10589.173" y="1563.0"/>
        <point2 x="10880.794" y="1916.0625"/>
        <ID1 xsi:type="node">1292</ID1>
        <ID2 xsi:type="node">1362</ID2>
        <ctrlPoint0 x="10589.527" y="1888.6511" xsi:type="point"/>
        <ctrlPoint1 x="10882.611" y="1843.6821" xsi:type="point"/>
    </child>
    <child ID="1372" layerID="1" created="1277498507442" x="10011.081"
        y="622.71875" width="491.7666" height="814.03125"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/70dc3fa77f0001010a5304616bf72ea2</URIString>
        <point1 x="10502.327" y="623.21875"/>
        <point2 x="10011.581" y="1436.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1235</ID2>
        <ctrlPoint0 x="10518.578" y="1417.4082" xsi:type="point"/>
        <ctrlPoint1 x="10011.002" y="1354.4216" xsi:type="point"/>
    </child>
    <child ID="1373" layerID="1" created="1277498564390" x="10221.044"
        y="622.75" width="282.20215" height="814.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/70dc3fa97f0001010a530461bed23383</URIString>
        <point1 x="10502.276" y="623.25"/>
        <point2 x="10221.544" y="1436.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1329</ID2>
        <ctrlPoint0 x="10516.788" y="1418.6824" xsi:type="point"/>
        <ctrlPoint1 x="10220.849" y="1345.7263" xsi:type="point"/>
    </child>
    <child ID="1374" label="AssetType" layerID="1"
        created="1277498968527" x="11120.202" y="973.225" width="172.5"
        height="157.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/70e093677f0001010a53046127e011fc</URIString>
        <child ID="1312" label="steps | MANY | PIPELINESTEP"
            created="1272407869366" x="34.0" y="23.0" width="177.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/417945b67f00010135ea571113dfcef1</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1508"
            label="Examples: Character FuryCharacter Vehicle Prop Environment Shot"
            created="1277558023775" x="34.0" y="43.25" width="80.0"
            height="108.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7464cb547f0001014a6b2ab78c34774b</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Examples:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Character
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      FuryCharacter
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Vehicle
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Prop
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Environment
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Shot
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Examples: Character FuryCharacter Vehicle Prop Environment Shot</label>
        </child>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="1396" label="Status" layerID="1" created="1277500787817"
        x="9870.169" y="796.2019" width="143.25" height="66.5"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/70fbee177f0001010a53046131252ebc</URIString>
        <child ID="1397" label="shortName | UNICODE"
            created="1277500787818" x="34.0" y="23.0" width="138.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/70fbee187f0001010a53046192e2ccce</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1398" label="thumbnail | ONE | FILE"
            created="1277500787818" x="34.0" y="43.25" width="135.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/70fbee187f0001010a530461e8d8f372</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="1402" label="Group" layerID="1" created="1277500921470"
        x="9713.752" y="1436.2256" width="165.75" height="127.8125"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/70ff4c457f0001010a5304618b714b63</URIString>
        <child ID="1493" label="User" created="1277544458699" x="34.0"
            y="23.0" width="168.0" height="104.75" strokeWidth="1.0"
            autoSized="true" xsi:type="node">
            <fillColor>#ECFFD4</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/73962aec7f000101783f472b2cd933de</URIString>
            <child ID="1494" label="Can create User | BOOLEAN"
                created="1277544458699" x="34.0" y="23.0" width="167.0"
                height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
                <fillColor>#FDE888</fillColor>
                <strokeColor>#776D6D</strokeColor>
                <textColor>#000000</textColor>
                <font>Arial-plain-12</font>
                <metadata-list category-list-size="1"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                    <metadata xsi:type="vue-metadata-element">
                        <value></value>
                        <key>http://vue.tufts.edu/vue.rdfs#none</key>
                        <type>1</type>
                    </metadata>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/73962aec7f000101783f472b9696ba5b</URIString>
                <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
            </child>
            <child ID="1495" label="Can read User | BOOLEAN"
                created="1277544458699" x="34.0" y="42.5" width="158.0"
                height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
                <fillColor>#FDE888</fillColor>
                <strokeColor>#776D6D</strokeColor>
                <textColor>#000000</textColor>
                <font>Arial-plain-12</font>
                <metadata-list category-list-size="1"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                    <metadata xsi:type="vue-metadata-element">
                        <value></value>
                        <key>http://vue.tufts.edu/vue.rdfs#none</key>
                        <type>1</type>
                    </metadata>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/73962aec7f000101783f472b5449b796</URIString>
                <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
            </child>
            <child ID="1496" label="Can update User | BOOLEAN"
                created="1277544458700" x="34.0" y="62.0" width="171.0"
                height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
                <fillColor>#FDE888</fillColor>
                <strokeColor>#776D6D</strokeColor>
                <textColor>#000000</textColor>
                <font>Arial-plain-12</font>
                <metadata-list category-list-size="1"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                    <metadata xsi:type="vue-metadata-element">
                        <value></value>
                        <key>http://vue.tufts.edu/vue.rdfs#none</key>
                        <type>1</type>
                    </metadata>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/73962aec7f000101783f472be92cb359</URIString>
                <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
            </child>
            <child ID="1497" label="Can delete User | BOOLEAN"
                created="1277544458700" x="34.0" y="81.5" width="167.0"
                height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
                <fillColor>#FDE888</fillColor>
                <strokeColor>#776D6D</strokeColor>
                <textColor>#000000</textColor>
                <font>Arial-plain-12</font>
                <metadata-list category-list-size="1"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                    <metadata xsi:type="vue-metadata-element">
                        <value></value>
                        <key>http://vue.tufts.edu/vue.rdfs#none</key>
                        <type>1</type>
                    </metadata>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/73962aec7f000101783f472bed2662c1</URIString>
                <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
            </child>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1503" label="other things..." created="1277544525089"
            x="34.0" y="104.5625" width="85.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7396a2bf7f000101783f472b0c288dca</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1404" label="Comment / Review" layerID="1"
        created="1277501812254" x="10328.292" y="1436.2256"
        width="144.0" height="66.5" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/710b81ac7f0001010a5304614a05d19a</URIString>
        <child ID="1421" label="body | UNICODE" created="1277503117512"
            x="34.0" y="23.0" width="102.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/712a60dd7f0001010a530461d74d63aa</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1405" label="to | ONE | ENTITY"
            created="1277501812255" x="34.0" y="43.25" width="106.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/710b81ac7f0001010a5304615407b23b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1443" layerID="1" created="1277507223177" x="9796.536"
        y="622.75" width="706.26465" height="814.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/715de2a17f0001010a5304617d6a59d3</URIString>
        <point1 x="10502.301" y="623.25"/>
        <point2 x="9797.036" y="1436.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1402</ID2>
        <ctrlPoint0 x="10517.511" y="1411.089" xsi:type="point"/>
        <ctrlPoint1 x="9797.605" y="1347.4504" xsi:type="point"/>
    </child>
    <child ID="1444" label="Playblast / Flipbook" layerID="1"
        created="1277507592356" x="11045.605" y="1436.2256"
        width="147.0" height="66.5" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/716433b77f0001010a530461ea2689a9</URIString>
        <child ID="1450" label="of | ONE | ASSETBASE"
            created="1277507592357" x="34.0" y="23.0" width="134.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/716433b87f0001010a530461ae077f28</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1938" label="file | ONE | FILE"
            created="1288269754490" x="34.0" y="43.25" width="96.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f2dcabc17f0001010d9438de492b2f36</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1465" label="ImageFormat" layerID="1"
        created="1277508730708" x="10232.845" y="797.0019" width="147.0"
        height="127.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7175e3647f0001010a5304618afb3c6d</URIString>
        <child ID="1468" label="width | INTEGER" created="1277508730709"
            x="34.0" y="23.0" width="102.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7175e3647f0001010a530461c2444b8a</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1469" label="height | INTEGER"
            created="1277508787050" x="34.0" y="43.25" width="107.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7175e3647f0001010a530461a525aa4a</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1471" label="device_aspect | FLOAT"
            created="1277508818841" x="34.0" y="63.5" width="136.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7175e3657f0001010a530461d423e0c0</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1470" label="pixel_aspect | FLOAT"
            created="1277508794355" x="34.0" y="83.75" width="126.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7175e3647f0001010a530461ed5f93c3</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1797" label="print_resolution | FLOAT"
            created="1279319466446" x="34.0" y="104.0" width="143.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/dd623f737f0001010c4cdf7e1538b03a</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="1475" layerID="1" created="1277542415873" x="10501.8"
        y="622.75" width="617.6699" height="814.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7376e9ec7f000101783f472b76efe287</URIString>
        <point1 x="10502.3" y="623.25"/>
        <point2 x="11118.97" y="1436.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1444</ID2>
        <ctrlPoint0 x="10517.578" y="1416.8022" xsi:type="point"/>
        <ctrlPoint1 x="11118.616" y="1350.8535" xsi:type="point"/>
    </child>
    <child ID="1509" label="Asset" layerID="1" created="1277558085543"
        x="10253.291" y="2275.6968" width="183.0" height="86.75"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/746640437f0001014a6b2ab79312b8c7</URIString>
        <child ID="1512" label="shots | MANY | SHOT"
            created="1277558085545" x="34.0" y="23.0" width="125.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#DAA9FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/746640447f0001014a6b2ab7fc9c5221</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1137" label="sequences | MANY | SEQUENCE"
            created="1272404571518" x="34.0" y="43.25" width="191.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#DAA9FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/4140ccdd7f00010135ea57116e5577a9</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1438" label="project | ONE | PROJECT"
            created="1277506578314" x="34.0" y="63.5" width="148.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#DAA9FF</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7153ccce7f0001010a53046132cef5b1</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1518" layerID="1" created="1277558130476" x="10344.101"
        y="1982.0" width="19.470703" height="294.25" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/746640447f0001014a6b2ab76aef8e77</URIString>
        <point1 x="10363.071" y="1982.5"/>
        <point2 x="10344.601" y="2275.75"/>
        <ID1 xsi:type="node">1088</ID1>
        <ID2 xsi:type="node">1509</ID2>
        <ctrlPoint0 x="10363.987" y="2141.4014" xsi:type="point"/>
        <ctrlPoint1 x="10344.124" y="2167.523" xsi:type="point"/>
    </child>
    <child ID="1555"
        label="STALKER OBJECT MODEL&#xa;INHERITANCE DIAGRAM v1.5.0"
        layerID="1" created="1279119389330" x="10158.136" y="46.376953"
        width="501.333" height="102.66669" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#B5B995</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-18</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/d175941d7f0001014ed1a34a819236b1</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1817" label="Shows implemented classes" layerID="1"
        created="1282128100173" x="10725.871" y="190.40186"
        width="208.0" height="18.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/84ca7c997f00010138aea9817270f61e</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Shows implemented classes
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Shows implemented classes</label>
    </child>
    <child ID="1879" label="Shows implemented attributes" layerID="1"
        created="1288167062202" x="10725.871" y="251.76364"
        width="302.0" height="15.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/ecbe81757f0001012cc821ef070ba546</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Shows implemented attributes
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Shows implemented attributes</label>
    </child>
    <child ID="1887" label="Entity" layerID="1" created="1288257108731"
        x="10441.4795" y="577.0019" width="120.75" height="46.25"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f21c2a7a7f0001010d9438de5c6ad321</URIString>
        <child ID="1906" label="tags | MANY | TAG"
            created="1288257253087" x="34.0" y="23.0" width="108.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#7F7F7F</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f220e0137f0001010d9438de0e9e63e0</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="1901" label="SimpleEntity" layerID="1"
        created="1288257253086" x="10418.232" y="303.87714"
        width="155.25" height="147.5" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f220e0127f0001010d9438de61473dd2</URIString>
        <child ID="2263" label="name | UNICODE" created="1292744446733"
            x="34.0" y="23.0" width="108.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#7F7F7F</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/ff73db697f0001015481be8a5451779a</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2264" label="description | UNICODE"
            created="1292744446733" x="34.0" y="43.25" width="137.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#7F7F7F</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/ff73db697f0001015481be8af558ee50</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1888" label="created_by | ONE | USER"
            created="1288257108731" x="34.0" y="63.5" width="149.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#7F7F7F</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f21c2a7a7f0001010d9438de2db62acf</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1889" label="updated_by | ONE | USER"
            created="1288257108731" x="34.0" y="83.75" width="153.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#7F7F7F</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f21c2a7a7f0001010d9438de885e42f6</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1890" label="date_created | DATETIME"
            created="1288257108732" x="34.0" y="104.0" width="150.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#7F7F7F</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f21c2a7a7f0001010d9438de584fbe77</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="1891" label="date_updated | DATETIME"
            created="1288257108732" x="34.0" y="124.25" width="154.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#7F7F7F</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/f21c2a7a7f0001010d9438dead15905c</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="1911" layerID="1" created="1288257402699" x="10501.738"
        y="622.75" width="88.41797" height="814.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f220e0137f0001010d9438de14a43748</URIString>
        <point1 x="10502.238" y="623.25"/>
        <point2 x="10589.656" y="1436.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1292</ID2>
        <ctrlPoint0 x="10515.397" y="1416.7573" xsi:type="point"/>
        <ctrlPoint1 x="10590.379" y="1352.8901" xsi:type="point"/>
    </child>
    <child ID="1912" layerID="1" created="1288257599993" x="9941.1"
        y="622.75" width="562.2461" height="174.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f22534227f0001010d9438dee0d42673</URIString>
        <point1 x="10502.846" y="623.25"/>
        <point2 x="9941.6" y="796.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1396</ID2>
        <ctrlPoint0 x="10508.54" y="756.11957" xsi:type="point"/>
        <ctrlPoint1 x="9941.181" y="724.45795" xsi:type="point"/>
    </child>
    <child ID="1913" layerID="1" created="1288257601892" x="10124.005"
        y="622.75" width="378.54297" height="173.9375" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f22534227f0001010d9438dea8c2b1fc</URIString>
        <point1 x="10502.048" y="623.25"/>
        <point2 x="10124.505" y="796.1875"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1355</ID2>
        <ctrlPoint0 x="10503.179" y="758.3768" xsi:type="point"/>
        <ctrlPoint1 x="10123.725" y="721.8007" xsi:type="point"/>
    </child>
    <child ID="1915" layerID="1" created="1288257624543" x="10309.928"
        y="622.75" width="193.11035" height="174.75" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f22534227f0001010d9438de64236ba0</URIString>
        <point1 x="10502.538" y="623.25"/>
        <point2 x="10310.428" y="797.0"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1465</ID2>
        <ctrlPoint0 x="10506.553" y="759.0667" xsi:type="point"/>
        <ctrlPoint1 x="10315.494" y="718.03754" xsi:type="point"/>
    </child>
    <child ID="1918" layerID="1" created="1288257690703" x="10504.3125"
        y="622.75" width="1548.7979" height="174.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f22534237f0001010d9438dede87b33c</URIString>
        <point1 x="10504.8125" y="623.25"/>
        <point2 x="12052.61" y="796.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1299</ID2>
        <ctrlPoint0 x="10522.233" y="759.45795" xsi:type="point"/>
        <ctrlPoint1 x="12053.721" y="659.6436" xsi:type="point"/>
    </child>
    <child ID="1919" layerID="1" created="1288257693210" x="10502.108"
        y="622.75" width="1192.0342" height="174.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f22534237f0001010d9438de69c8feac</URIString>
        <point1 x="10502.608" y="623.25"/>
        <point2 x="11693.643" y="796.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1145</ID2>
        <ctrlPoint0 x="10506.833" y="752.7148" xsi:type="point"/>
        <ctrlPoint1 x="11694.533" y="704.3411" xsi:type="point"/>
    </child>
    <child ID="1929" layerID="1" created="1288267347449" x="10502.053"
        y="622.75" width="220.28613" height="174.0625" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f2bb5ec47f0001010d9438de1533e2c4</URIString>
        <point1 x="10502.553" y="623.25"/>
        <point2 x="10721.839" y="796.3125"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1284</ID2>
        <ctrlPoint0 x="10506.393" y="750.38666" xsi:type="point"/>
        <ctrlPoint1 x="10720.957" y="724.6352" xsi:type="point"/>
    </child>
    <child ID="1930" layerID="1" created="1288267622487" x="10501.828"
        y="622.75" width="829.52344" height="173.96875"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f2bd21e47f0001010d9438de90bcd0c1</URIString>
        <point1 x="10502.328" y="623.25"/>
        <point2 x="11330.852" y="796.21875"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">2397</ID2>
        <ctrlPoint0 x="10504.886" y="748.06256" xsi:type="point"/>
        <ctrlPoint1 x="11328.947" y="721.1773" xsi:type="point"/>
    </child>
    <child ID="1933" layerID="1" created="1288268055042" x="10501.835"
        y="622.75" width="437.43066" height="814.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f2c6c0257f0001010d9438de6add753c</URIString>
        <point1 x="10502.335" y="623.25"/>
        <point2 x="10938.766" y="1436.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1227</ID2>
        <ctrlPoint0 x="10518.786" y="1415.7544" xsi:type="point"/>
        <ctrlPoint1 x="10939.231" y="1349.8295" xsi:type="point"/>
    </child>
    <child ID="1934" layerID="1" created="1288268057279" x="10399.609"
        y="622.75" width="104.58984" height="813.875" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f2c6c0257f0001010d9438dedaff0b3d</URIString>
        <point1 x="10502.304" y="623.25"/>
        <point2 x="10400.109" y="1436.125"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1404</ID2>
        <ctrlPoint0 x="10517.768" y="1418.0369" xsi:type="point"/>
        <ctrlPoint1 x="10399.609" y="1344.9443" xsi:type="point"/>
    </child>
    <child ID="1935" layerID="1" created="1288268059310" x="10501.803"
        y="622.75" width="268.9541" height="814.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f2c6c0257f0001010d9438de4ef74d59</URIString>
        <point1 x="10502.303" y="623.25"/>
        <point2 x="10770.257" y="1436.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">1157</ID2>
        <ctrlPoint0 x="10517.722" y="1418.6931" xsi:type="point"/>
        <ctrlPoint1 x="10771.16" y="1365.5742" xsi:type="point"/>
    </child>
    <child ID="1940" label="Package" layerID="1" created="1288424104620"
        x="11206.72" y="1916.0773" width="160.5" height="46.25"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FC938D</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/fc1178ae7f00010120d48785675aa223</URIString>
        <child ID="1945" label="asset | MANY | ASSETBASE"
            created="1288424104621" x="34.0" y="23.0" width="161.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/fc1178af7f00010120d48785088a5d16</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1950" layerID="1" created="1288424120074" x="10588.702"
        y="1563.5" width="699.0088" height="353.125" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/fc1178b07f00010120d4878508d5a5da</URIString>
        <point1 x="10589.202" y="1564.0"/>
        <point2 x="11287.211" y="1916.125"/>
        <ID1 xsi:type="node">1292</ID1>
        <ID2 xsi:type="node">1940</ID2>
        <ctrlPoint0 x="10589.7" y="1889.1465" xsi:type="point"/>
        <ctrlPoint1 x="11288.026" y="1837.5964" xsi:type="point"/>
    </child>
    <child ID="1957" layerID="1" created="1288799345809" x="10501.802"
        y="622.75" width="674.83594" height="173.96875"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/126dc1f67f0001014196c169c59591bf</URIString>
        <point1 x="10502.302" y="623.25"/>
        <point2 x="11176.138" y="796.21875"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">2180</ID2>
        <ctrlPoint0 x="10504.935" y="759.50385" xsi:type="point"/>
        <ctrlPoint1 x="11179.17" y="719.4908" xsi:type="point"/>
    </child>
    <child ID="1971" label="link_type | UNICODE" layerID="1"
        created="1289268540831" x="11962.97" y="251.75195" width="124.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/2e65a7f77f0001010115c6cbe23f0f69</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1973" label="reference source file" layerID="1"
        created="1289268558946" x="11960.97" y="275.37695" width="62.0"
        height="33.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/2e65a7f87f0001010115c6cbdf26cf7a</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      reference
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      source file
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>reference source file</label>
    </child>
    <child ID="1995" label="Delivery" layerID="1"
        created="1289688586892" x="11396.252" y="1916.0773"
        width="123.0" height="46.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/476ff9f37f0001015a3184d866b3d9f0</URIString>
        <child ID="2001" label="files | MANY | LINK"
            created="1289688586898" x="34.0" y="23.0" width="111.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/476ff9f47f0001015a3184d89f755940</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2005" layerID="1" created="1289688647878" x="10589.355"
        y="1562.9375" width="869.01465" height="353.5625"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/476ff9f57f0001015a3184d86becdbe1</URIString>
        <point1 x="10589.855" y="1563.4375"/>
        <point2 x="11457.87" y="1916.0"/>
        <ID1 xsi:type="node">1292</ID1>
        <ID2 xsi:type="node">1995</ID2>
        <ctrlPoint0 x="10593.701" y="1889.1553" xsi:type="point"/>
        <ctrlPoint1 x="11458.292" y="1832.1589" xsi:type="point"/>
    </child>
    <child ID="2012" label="Structure" layerID="1"
        created="1290373811327" x="10829.72" y="796.225" width="239.25"
        height="167.75" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/704adc107f0001012ed4f13aa93265ac</URIString>
        <child ID="2017" label="project_template | STRING"
            created="1290373958896" x="34.0" y="23.0" width="157.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/704adc117f0001012ed4f13ae0ef0e20</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2014"
            label="Examples: ASSETS SEQUENCES SEQUENCES\EDIT_MOVIE ..."
            created="1290373811339" x="34.0" y="43.25" width="152.0"
            height="78.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/704adc127f0001012ed4f13a3db45dfe</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Examples:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      ASSETS
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      SEQUENCES
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      SEQUENCES\EDIT_MOVIE
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      ...
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Examples: ASSETS SEQUENCES SEQUENCES\EDIT_MOVIE ...</label>
        </child>
        <child ID="1953" label="asset_templates | MANY | TYPETEMPLATE"
            created="1288799242289" x="34.0" y="124.25" width="245.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/126dc1837f0001014196c1697d2d6390</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2128"
            label="reference_templates | MANY | TYPETEMPLATE"
            created="1290427967501" x="34.0" y="144.5" width="266.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7389b24d7f0001010b45ad3d763af44e</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2016" layerID="1" created="1290373841415" x="10502.081"
        y="622.75" width="453.042" height="173.96875" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/704adc147f0001012ed4f13a8b835d41</URIString>
        <point1 x="10502.581" y="623.25"/>
        <point2 x="10954.623" y="796.21875"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">2012</ID2>
        <ctrlPoint0 x="10506.642" y="752.50385" xsi:type="point"/>
        <ctrlPoint1 x="10958.821" y="729.48444" xsi:type="point"/>
    </child>
    <child ID="2018" label="Pipeline" layerID="1"
        created="1290378049557" x="11762.686" y="251.75195"
        width="181.5" height="46.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/708b2a007f0001012ed4f13ad95c4242</URIString>
        <child ID="2019" label="head | ONE | WORKFLOWNODE"
            created="1290378049558" x="34.0" y="23.0" width="189.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/708b2a017f0001012ed4f13a606c2c6b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2021" label="WorkflowNode" layerID="1"
        created="1290378204385" x="11738.686" y="316.75195"
        width="141.75" height="86.75" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/708b2a017f0001012ed4f13a1c7a9e64</URIString>
        <child ID="2022" label="steps | ONE | STEP"
            created="1290378204385" x="34.0" y="23.0" width="117.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/708b2a027f0001012ed4f13ad05d13f6</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2023" label="parent | ONE | STEP"
            created="1290378228804" x="34.0" y="43.25" width="121.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/708b2a037f0001012ed4f13ab8c3cf1d</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2024" label="children | MANY | STEP"
            created="1290378237026" x="34.0" y="63.5" width="136.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/708b2a037f0001012ed4f13aa6e3f1bc</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2026" label="PROBLEM" layerID="1" created="1290415153137"
        x="12753.83" y="580.21045" width="215.0" height="92.0"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FCDBD9</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c7681c7f0001010b45ad3d65da5015</URIString>
        <child ID="2025"
            label="Where to save the templates, or more clearly, where to save the data &#xa;      that holds which file of which pipeline_step should saved where..."
            created="1290379453440" x="5.0" y="23.0" width="205.0"
            height="63.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/709d95a57f0001012ed4f13a4667f382</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Where to save the templates, or more clearly, where to save the data 
      that holds which file of which pipeline_step should saved where...
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Where to save the templates, or more clearly, where to save the data 
      that holds which file of which pipeline_step should saved where...</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2027" label="Hold in AssetType" layerID="1"
        created="1290415471563" x="12585.413" y="825.87695"
        width="160.0" height="107.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c7681e7f0001010b45ad3dbd6e27e5</URIString>
        <child ID="2029"
            label="Asset Type holds a lot of things, so may be the asset type should hold the data that shows where to save a specific type"
            created="1290415523885" x="5.0" y="23.0" width="150.0"
            height="78.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72c7681f7f0001010b45ad3d77bc2d11</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Asset Type holds a lot of things, so may be the asset type should hold 
      the
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      data that shows where to save a specific type
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Asset Type holds a lot of things, so may be the asset type should hold the data that shows where to save a specific type</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2028" label="SOLUTION 1" layerID="1"
        created="1290415471574" x="12706.315" y="671.71094"
        width="119.916016" height="154.66602" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c768217f0001010b45ad3d27ead190</URIString>
        <point1 x="12825.731" y="672.21094"/>
        <point2 x="12706.815" y="825.87695"/>
        <ID1 xsi:type="node">2026</ID1>
        <ID2 xsi:type="node">2027</ID2>
    </child>
    <child ID="2031" label="limits flexibility" layerID="1"
        created="1290415567637" x="12585.413" y="995.37695"
        width="160.0" height="107.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c768227f0001010b45ad3de419a2bb</URIString>
        <child ID="2033"
            label="This leads a weird setup where an object has to be saved to the same &#xa;      place in every project, this limits the flexibility we aim"
            created="1290415575363" x="5.0" y="23.0" width="150.0"
            height="78.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72c768237f0001010b45ad3ddd5305d2</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      This leads a weird setup where an object has to be saved to the same 
      place in every project, this limits the flexibility we aim
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>This leads a weird setup where an object has to be saved to the same 
      place in every project, this limits the flexibility we aim</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2032" layerID="1" created="1290415567645" x="12664.913"
        y="932.37695" width="1.0" height="63.5" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c768247f0001010b45ad3dedb39d1c</URIString>
        <point1 x="12665.413" y="932.87695"/>
        <point2 x="12665.413" y="995.37695"/>
        <ID1 xsi:type="node">2027</ID1>
        <ID2 xsi:type="node">2031</ID2>
    </child>
    <child ID="2035" label="Hold in Project" layerID="1"
        created="1290415693380" x="12901.163" y="835.37695"
        width="153.0" height="77.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c768257f0001010b45ad3d2cd5572c</URIString>
        <child ID="2037"
            label="hold the data in project node, so any project can have different setups"
            created="1290415702905" x="5.0" y="23.0" width="143.0"
            height="48.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72c768267f0001010b45ad3d7b74ae69</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      hold the data in project node, so any project can have different setups
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>hold the data in project node, so any project can have different setups</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2036" label="SOLUTION 2" layerID="1"
        created="1290415693397" x="12882.4375" y="671.71094"
        width="77.6416" height="164.16602" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c768287f0001010b45ad3ddc9a3886</URIString>
        <point1 x="12882.9375" y="672.21094"/>
        <point2 x="12959.579" y="835.37695"/>
        <ID1 xsi:type="node">2026</ID1>
        <ID2 xsi:type="node">2035</ID2>
    </child>
    <child ID="2038" label="special settings for every node" layerID="1"
        created="1290415727634" x="12884.163" y="971.37695"
        width="187.0" height="152.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c768297f0001010b45ad3d2ac3c4b6</URIString>
        <child ID="2040"
            label="this needs to have an entry for every asset type, so if I'm going to &#xa;      hold a template for assets I need to specify that this template is for assets, and if I want to have a template for shots, I need to specify that this template is for shots"
            created="1290415748194" x="5.0" y="23.0" width="177.0"
            height="123.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72c768297f0001010b45ad3d14b50bfc</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      this needs to have an entry for every asset type, so if I'm going to 
      hold a template for assets I need to specify that this template is for 
      assets, and if I want to have a template for shots, I need to specify 
      that this template is for shots
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>this needs to have an entry for every asset type, so if I'm going to 
      hold a template for assets I need to specify that this template is for assets, and if I want to have a template for shots, I need to specify that this template is for shots</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2039" layerID="1" created="1290415727642" x="12977.163"
        y="911.87695" width="1.0" height="60.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c7682b7f0001010b45ad3d805a8614</URIString>
        <point1 x="12977.663" y="912.37695"/>
        <point2 x="12977.663" y="971.37695"/>
        <ID1 xsi:type="node">2035</ID1>
        <ID2 xsi:type="node">2038</ID2>
    </child>
    <child ID="2043" label="REASONABLE" layerID="1"
        created="1290415848293" x="12933.163" y="1184.377" width="89.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c7682c7f0001010b45ad3d801617fc</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2044" layerID="1" created="1290415848302" x="12977.163"
        y="1122.877" width="1.0" height="62.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c7682d7f0001010b45ad3dc2a36449</URIString>
        <point1 x="12977.663" y="1123.377"/>
        <point2 x="12977.663" y="1184.377"/>
        <ID1 xsi:type="node">2038</ID1>
        <ID2 xsi:type="node">2043</ID2>
    </child>
    <child ID="2045" label="BAD" layerID="1" created="1290415882271"
        x="12627.413" y="1189.377" width="76.0" height="23.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c8b39c7f0001010b45ad3d3de72c20</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2046" layerID="1" created="1290415882275" x="12664.913"
        y="1101.877" width="1.0" height="88.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c8b39d7f0001010b45ad3dbf4d4a87</URIString>
        <point1 x="12665.413" y="1102.377"/>
        <point2 x="12665.413" y="1189.377"/>
        <ID1 xsi:type="node">2031</ID1>
        <ID2 xsi:type="node">2045</ID2>
    </child>
    <child ID="2048" label="how to connect" layerID="1"
        created="1290415915729" x="12897.663" y="1259.377" width="160.0"
        height="60.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c8b39e7f0001010b45ad3dce9e9452</URIString>
        <child ID="2050" label="how to connect the data, in this case"
            created="1290415921232" x="5.0" y="23.0" width="150.0"
            height="31.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72c8b39e7f0001010b45ad3d443056e8</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 11; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 11; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 11; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:12;"&gt;how to connect the data, in this case&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>how to connect the data, in this case</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2049" layerID="1" created="1290415915733" x="12977.163"
        y="1206.877" width="1.0" height="53.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72c8b3a07f0001010b45ad3d861cccb5</URIString>
        <point1 x="12977.663" y="1207.377"/>
        <point2 x="12977.663" y="1259.377"/>
        <ID1 xsi:type="node">2043</ID1>
        <ID2 xsi:type="node">2048</ID2>
    </child>
    <child ID="2051" label="AssetType" layerID="1"
        created="1290415957287" x="12786.163" y="1403.377" width="169.0"
        height="92.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72ccceac7f0001010b45ad3deca8e4e1</URIString>
        <child ID="2054"
            label="so for every assetType given to the system, the user can specify the &#xa;      default location to save"
            created="1290415993540" x="5.0" y="23.0" width="159.0"
            height="63.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72cccead7f0001010b45ad3d050b14ca</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      so for every assetType given to the system, the user can specify the 
      default location to save
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>so for every assetType given to the system, the user can specify the 
      default location to save</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2052" layerID="1" created="1290415957292" x="12900.926"
        y="1318.877" width="57.174805" height="85.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72ccceaf7f0001010b45ad3d72cbe1eb</URIString>
        <point1 x="12957.601" y="1319.377"/>
        <point2 x="12901.426" y="1403.377"/>
        <ID1 xsi:type="node">2048</ID1>
        <ID2 xsi:type="node">2051</ID2>
    </child>
    <child ID="2057" label="PipelineStep" layerID="1"
        created="1290416080796" x="13016.663" y="1396.377" width="160.0"
        height="158.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72ccceb07f0001010b45ad3d6a47dcac</URIString>
        <child ID="2059"
            label="the files are produced in pipeline steps, for a &quot;Character&quot; assetType, &#xa;      the &quot;Modeling&quot; pipelne step produces the file, so we need three data to hold, one the assetType, second the pipeline step, and third the template string"
            created="1290416089913" x="5.0" y="23.0" width="150.0"
            height="129.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72ccceb07f0001010b45ad3d80acd543</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 11; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 11; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 11; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      the files are produced in pipeline steps, for a &amp;quot;Character&amp;quot; assetType, 
      the &amp;quot;Modeling&amp;quot; pipelne step produces the file, so we need three data to 
      hold, one the assetType, second the pipeline step, and third the 
      template string
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>the files are produced in pipeline steps, for a "Character" assetType, 
      the "Modeling" pipelne step produces the file, so we need three data to hold, one the assetType, second the pipeline step, and third the template string</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2058" layerID="1" created="1290416080803" x="12996.357"
        y="1318.877" width="50.262695" height="78.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72ccceb27f0001010b45ad3d93aaab40</URIString>
        <point1 x="12996.856" y="1319.377"/>
        <point2 x="13046.119" y="1396.377"/>
        <ID1 xsi:type="node">2048</ID1>
        <ID2 xsi:type="node">2057</ID2>
    </child>
    <child ID="2060" label="Idea 2" layerID="1" created="1290416289541"
        x="12923.163" y="1621.377" width="160.0" height="107.0"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FC938D</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72d4e8727f0001010b45ad3d6534da51</URIString>
        <child ID="2062"
            label="Create a new composite foreign key, that holds a key to one asset type &#xa;      object and a pipeline step, and has a string template"
            created="1290416301932" x="5.0" y="23.0" width="150.0"
            height="78.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72d4e8727f0001010b45ad3d7e0392c9</URIString>
            <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Create a new composite foreign key, that holds a key to one asset type 
      object and a pipeline step, and has a string template
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Create a new composite foreign key, that holds a key to one asset type 
      object and a pipeline step, and has a string template</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2061" layerID="1" created="1290416289545" x="13027.737"
        y="1553.877" width="32.40039" height="68.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72d4e8737f0001010b45ad3d19b9fc7e</URIString>
        <point1 x="13059.638" y="1554.377"/>
        <point2 x="13028.237" y="1621.377"/>
        <ID1 xsi:type="node">2057</ID1>
        <ID2 xsi:type="node">2060</ID2>
    </child>
    <child ID="2063" label="Structure" layerID="1"
        created="1290416676242" x="12942.163" y="1783.377" width="124.0"
        height="62.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72d4e8737f0001010b45ad3d683e5230</URIString>
        <child ID="2065" label="this can work with the structure system"
            created="1290416682757" x="5.0" y="23.0" width="114.0"
            height="33.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72d4e8737f0001010b45ad3db5912744</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      this can work with the structure system
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>this can work with the structure system</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2064" layerID="1" created="1290416676246" x="13003.047"
        y="1727.875" width="1.3945312" height="56.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72d4e8747f0001010b45ad3d2421dadd</URIString>
        <point1 x="13003.547" y="1728.375"/>
        <point2 x="13003.941" y="1783.375"/>
        <ID1 xsi:type="node">2060</ID1>
        <ID2 xsi:type="node">2063</ID2>
    </child>
    <child ID="2066" layerID="1" created="1290416717375" x="12897.192"
        y="1494.877" width="75.03516" height="127.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72d4e8747f0001010b45ad3dfa561263</URIString>
        <point1 x="12897.692" y="1495.377"/>
        <point2 x="12971.728" y="1621.377"/>
        <ID1 xsi:type="node">2051</ID1>
        <ID2 xsi:type="node">2060</ID2>
    </child>
    <child ID="2067" label="idea 1" layerID="1" created="1290416821416"
        x="12698.252" y="1588.377" width="160.0" height="62.0"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FC938D</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72d6ca677f0001010b45ad3d78d6eb10</URIString>
        <child ID="2069"
            label="use assetType side by side with a template"
            created="1290416826833" x="5.0" y="23.0" width="150.0"
            height="33.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72d6ca687f0001010b45ad3d900a2d2c</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 11; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 11; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 11; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      &lt;font style="font-size:12;"&gt;use assetType side by side with a template&lt;/font&gt;
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>use assetType side by side with a template</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2068" layerID="1" created="1290416821420" x="12794.604"
        y="1494.877" width="51.554688" height="94.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72d6ca687f0001010b45ad3dde441d00</URIString>
        <point1 x="12845.658" y="1495.377"/>
        <point2 x="12795.104" y="1588.377"/>
        <ID1 xsi:type="node">2051</ID1>
        <ID2 xsi:type="node">2067</ID2>
    </child>
    <child ID="2075" label="BIGGER QUESTION" layerID="1"
        created="1290417771427" x="13785.086" y="569.37695"
        width="160.0" height="92.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FCDBD9</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72e63ba77f0001010b45ad3d2724344a</URIString>
        <child ID="2077"
            label="Should I have a template for any entity those have a connection with the &#xa;      file system"
            created="1290417822261" x="5.0" y="23.0" width="150.0"
            height="63.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/72e63ba87f0001010b45ad3dc2870b40</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Should I have a template for any entity those have a connection with the 
      file system
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Should I have a template for any entity those have a connection with the 
      file system</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2080" label="For Example?" layerID="1"
        created="1290417984688" x="13820.586" y="716.37695" width="88.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a57f0001010b45ad3d8a1153d0</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2081" layerID="1" created="1290417984692" x="13864.135"
        y="661.0" width="1.2451172" height="56.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a57f0001010b45ad3d490f63de</URIString>
        <point1 x="13864.881" y="661.5"/>
        <point2 x="13864.636" y="716.5"/>
        <ID1 xsi:type="node">2075</ID1>
        <ID2 xsi:type="node">2080</ID2>
    </child>
    <child ID="2082" label="where to save the a version of a task ?"
        layerID="1" created="1290418001363" x="13641.586" y="794.37695"
        width="233.0" height="51.5" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a67f0001010b45ad3d49b4e257</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2083" layerID="1" created="1290418001367" x="13787.314"
        y="738.87695" width="64.49512" height="56.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a67f0001010b45ad3ddebb1a70</URIString>
        <point1 x="13851.31" y="739.37695"/>
        <point2 x="13787.814" y="794.37695"/>
        <ID1 xsi:type="node">2080</ID1>
        <ID2 xsi:type="node">2082</ID2>
    </child>
    <child ID="2084" label="does it need to have a template ?"
        layerID="1" created="1290418016558" x="13653.086" y="905.0198"
        width="210.0" height="55.5" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a67f0001010b45ad3d95cb489f</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2085" layerID="1" created="1290418016563" x="13757.586"
        y="845.37695" width="1.0" height="60.142822" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a67f0001010b45ad3dc1ae5313</URIString>
        <point1 x="13758.086" y="845.87695"/>
        <point2 x="13758.086" y="905.0198"/>
        <ID1 xsi:type="node">2082</ID1>
        <ID2 xsi:type="node">2084</ID2>
    </child>
    <child ID="2086" label="where&#xa;to create&#xa;a sequence folder"
        layerID="1" created="1290418067315" x="13985.086" y="798.37695"
        width="110.0" height="53.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a77f0001010b45ad3d3f31f2fc</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2087" layerID="1" created="1290418067319" x="13884.893"
        y="738.87695" width="108.53711" height="60.436523"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a77f0001010b45ad3d06e536cd</URIString>
        <point1 x="13885.393" y="739.37695"/>
        <point2 x="13992.93" y="798.8135"/>
        <ID1 xsi:type="node">2080</ID1>
        <ID2 xsi:type="node">2086</ID2>
    </child>
    <child ID="2088"
        label="sequences are&#xa;dummy folders like projects"
        layerID="1" created="1290418090858" x="13952.586" y="892.62695"
        width="175.0" height="58.5" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a77f0001010b45ad3d2df9b014</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2089" layerID="1" created="1290418090865" x="14039.586"
        y="850.87695" width="1.0" height="42.25" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a87f0001010b45ad3d2466129e</URIString>
        <point1 x="14040.086" y="851.37695"/>
        <point2 x="14040.086" y="892.62695"/>
        <ID1 xsi:type="node">2086</ID1>
        <ID2 xsi:type="node">2088</ID2>
    </child>
    <child ID="2091"
        label="thus they are hidden in the&#xa;template code"
        layerID="1" created="1290418155937" x="13958.836" y="992.37695"
        width="162.5" height="65.5" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a87f0001010b45ad3d3c38709f</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2092" layerID="1" created="1290418155942" x="14039.586"
        y="950.62695" width="1.0" height="42.25" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a87f0001010b45ad3d908c11e0</URIString>
        <point1 x="14040.086" y="951.12695"/>
        <point2 x="14040.086" y="992.37695"/>
        <ID1 xsi:type="node">2088</ID1>
        <ID2 xsi:type="node">2091</ID2>
    </child>
    <child ID="2095"
        label="in fact it has, the whole idea&#xa;behind project.template is to&#xa;define the place to save a&#xa;version of a pipeline step"
        layerID="1" created="1290418232979" x="13675.086" y="1019.6626"
        width="166.0" height="68.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a97f0001010b45ad3d6fed6405</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2096" layerID="1" created="1290418232984" x="13757.586"
        y="960.0198" width="1.0" height="60.142822" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a97f0001010b45ad3d34de9e5c</URIString>
        <point1 x="13758.086" y="960.5198"/>
        <point2 x="13758.086" y="1019.6626"/>
        <ID1 xsi:type="node">2084</ID1>
        <ID2 xsi:type="node">2095</ID2>
    </child>
    <child ID="2100"
        label="how to pass the data to be used&#xa;inside templates"
        layerID="1" created="1290418291978" x="13665.086" y="1146.8054"
        width="186.0" height="38.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a97f0001010b45ad3d6728aea3</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2101" layerID="1" created="1290418291983" x="13757.586"
        y="1087.1626" width="1.0" height="60.142822" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113a97f0001010b45ad3d3911b327</URIString>
        <point1 x="13758.086" y="1087.6626"/>
        <point2 x="13758.086" y="1146.8054"/>
        <ID1 xsi:type="node">2095</ID1>
        <ID2 xsi:type="node">2100</ID2>
    </child>
    <child ID="2102"
        label="templates are jinja2 template, they&#xa;need variables, so how can I pass the&#xa;neccesary data to the version"
        layerID="1" created="1290418304858" x="13649.086" y="1243.9482"
        width="218.0" height="53.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113aa7f0001010b45ad3d9af06b7f</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2103" layerID="1" created="1290418304863" x="13757.586"
        y="1184.3054" width="1.0" height="60.142822" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113aa7f0001010b45ad3dd1e49c4e</URIString>
        <point1 x="13758.086" y="1184.8054"/>
        <point2 x="13758.086" y="1243.9482"/>
        <ID1 xsi:type="node">2100</ID1>
        <ID2 xsi:type="node">2102</ID2>
    </child>
    <child ID="2104"
        label="the templates should&#xa;be using the version itself,&#xa;so a template for a version&#xa;should be like:&#xa;&#xa;{{version.project.name}}/ASSETS/{{version.asset.code}}/&#xa;{{version.asset_type.pipeline_step.code}}/&#xa;{{version.asset.code}}_{{version.asset.sub_name}}&#xa;&#xa;where the desired template should look like&#xa;&#xa;{{project.name}}/ASSET/{{asset.code}}/{{pipeline_step.code}}...&#xa;&#xa;which is more clear then the previous one"
        layerID="1" created="1290418353149" x="13581.586" y="1356.0911"
        width="353.0" height="218.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113aa7f0001010b45ad3d3e1507b7</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2105" layerID="1" created="1290418353153" x="13757.586"
        y="1296.4482" width="1.0" height="60.142822" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72f113ab7f0001010b45ad3d1cbe64b2</URIString>
        <point1 x="13758.086" y="1296.9482"/>
        <point2 x="13758.086" y="1356.0911"/>
        <ID1 xsi:type="node">2102</ID1>
        <ID2 xsi:type="node">2104</ID2>
    </child>
    <child ID="2109"
        label="the template can be given these variables:&#xa;&#xa;project&#xa;sequence&#xa;asset&#xa;assetType&#xa;task&#xa;version&#xa;&#xa;so a user can by default use this template&#xa;variables"
        layerID="1" created="1290419014194" x="13637.586" y="1633.2339"
        width="241.0" height="173.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72fbe81f7f0001010b45ad3d3a6d4e41</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2110" layerID="1" created="1290419014198" x="13757.586"
        y="1573.5911" width="1.0" height="60.142822" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72fbe8207f0001010b45ad3d2b6e222b</URIString>
        <point1 x="13758.086" y="1574.0911"/>
        <point2 x="13758.086" y="1633.2339"/>
        <ID1 xsi:type="node">2104</ID1>
        <ID2 xsi:type="node">2109</ID2>
    </child>
    <child ID="2111"
        label="so the answer to the question is&#xa;&#xa;NO&#xa;&#xa;we don't have to have a template&#xa;for any entity"
        layerID="1" created="1290419270418" x="13664.086" y="1865.3767"
        width="188.0" height="98.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72fbe8207f0001010b45ad3df22cfe6c</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2112" layerID="1" created="1290419270423" x="13757.586"
        y="1805.7339" width="1.0" height="60.142822" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/72fbe8207f0001010b45ad3d28033eea</URIString>
        <point1 x="13758.086" y="1806.2339"/>
        <point2 x="13758.086" y="1865.3767"/>
        <ID1 xsi:type="node">2109</ID1>
        <ID2 xsi:type="node">2111</ID2>
    </child>
    <child ID="2113" label="Dailies" layerID="1" created="1290419327480"
        x="11898.752" y="321.22498" width="162.0" height="127.25"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/730007357f0001010b45ad3d07ff27f4</URIString>
        <child ID="2114" label="name | UNICODe" created="1290419327481"
            x="34.0" y="23.0" width="107.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/730007367f0001010b45ad3defdcfaa7</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2115" label="description | UNICODE"
            created="1290419327481" x="34.0" y="43.25" width="137.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/730007367f0001010b45ad3decb5acf5</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2116" label="date | DATETIME" created="1290419357443"
            x="34.0" y="63.5" width="102.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/730007367f0001010b45ad3ddddebc38</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2117" label="playlist | ONE | PLAYLIST"
            created="1290419377928" x="34.0" y="83.75" width="147.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/730007367f0001010b45ad3d622c693c</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2118" label="reviews | MANY | COMMENT"
            created="1290419404178" x="34.0" y="104.0" width="163.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/730007377f0001010b45ad3d61f092cd</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2122"
        label="{{jobServer.path}}/{{project.name}}/ASSETS/{{asset.name}}/{{pipeline_step.name}}/{{asset.code}}_{{asset.sub_name}}_{{pipeline_step.code}}_{{version.version}}.{{version.extension}}"
        layerID="1" created="1290422056611" x="11755.752" y="2810.5432"
        width="1014.0" height="18.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b29e7f0001010b45ad3d3481c615</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      {{jobServer.path}}/{{project.name}}/ASSETS/{{asset.name}}/{{pipeline_step.name}}/{{asset.code}}_{{asset.sub_name}}_{{pipeline_step.code}}_{{version.version}}.{{version.extension}}
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>{{jobServer.path}}/{{project.name}}/ASSETS/{{asset.name}}/{{pipeline_step.name}}/{{asset.code}}_{{asset.sub_name}}_{{pipeline_step.code}}_{{version.version}}.{{version.extension}}</label>
    </child>
    <child ID="2123"
        label="{{jobServer.path}}/{{project.name}}/{{sequence.name}}/{{pipeline_step.name}}/{{asset.name}}/{{asset.name}}_{{asset.sub_name}}_{{asset.type.name}}_{{asset.revision}}_{{asset.version}}_{{user.initials}}.{{extension}}"
        layerID="1" created="1290422114980" x="11757.419" y="2690.8767"
        width="1184.0" height="15.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b29f7f0001010b45ad3d44d7a3dc</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      {{jobServer.path}}/{{project.name}}/{{sequence.name}}/{{pipeline_step.name}}/{{asset.name}}/{{asset.name}}_{{asset.sub_name}}_{{asset.type.name}}_{{asset.revision}}_{{asset.version}}_{{user.initials}}.{{extension}}
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>{{jobServer.path}}/{{project.name}}/{{sequence.name}}/{{pipeline_step.name}}/{{asset.name}}/{{asset.name}}_{{asset.sub_name}}_{{asset.type.name}}_{{asset.revision}}_{{asset.version}}_{{user.initials}}.{{extension}}</label>
    </child>
    <child ID="2125" label="Character" layerID="1"
        created="1290422301646" x="11757.419" y="2674.8767" width="57.0"
        height="18.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b29f7f0001010b45ad3dd87058b5</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Character
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Character</label>
    </child>
    <child ID="2126" label="Vehicle" layerID="1" created="1290422319582"
        x="11757.419" y="2723.8767" width="43.0" height="18.0"
        strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b2a07f0001010b45ad3d0fe5de56</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Vehicle
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Vehicle</label>
    </child>
    <child ID="2127"
        label="{{jobServer.path}}/{{project.name}}/{{sequence.name}}/{{pipeline_step.name}}/{{asset.name}}/{{asset.name}}_{{asset.sub_name}}_{{asset.type.name}}_{{asset.revision}}_{{asset.version}}_{{user.initials}}.{{extension}}"
        layerID="1" created="1290422326023" x="11757.419" y="2742.3767"
        width="1184.0" height="15.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b2a07f0001010b45ad3d3559077d</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      {{jobServer.path}}/{{project.name}}/{{sequence.name}}/{{pipeline_step.name}}/{{asset.name}}/{{asset.name}}_{{asset.sub_name}}_{{asset.type.name}}_{{asset.revision}}_{{asset.version}}_{{user.initials}}.{{extension}}
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>{{jobServer.path}}/{{project.name}}/{{sequence.name}}/{{pipeline_step.name}}/{{asset.name}}/{{asset.name}}_{{asset.sub_name}}_{{asset.type.name}}_{{asset.revision}}_{{asset.version}}_{{user.initials}}.{{extension}}</label>
    </child>
    <child ID="2142" label="external references" layerID="1"
        created="1290428386234" x="11878.611" y="1748.5442"
        width="188.0" height="79.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b2a27f0001010b45ad3d774a4589</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2143"
        label="the template of a reference&#xa;can be saved inside project"
        layerID="1" created="1290428397581" x="11825.822" y="2111.2444"
        width="161.0" height="38.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#C1F780</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b2a27f0001010b45ad3d4fa061ad</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2144" layerID="1" created="1290428397586" x="11919.023"
        y="2053.3438" width="40.885742" height="58.40039"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b2a27f0001010b45ad3d045938fe</URIString>
        <point1 x="11959.41" y="2053.8438"/>
        <point2 x="11919.524" y="2111.2441"/>
        <ID1 xsi:type="node">2167</ID1>
        <ID2 xsi:type="node">2143</ID2>
    </child>
    <child ID="2145"
        label="need to have another data column&#xa;then the templates column,&#xa;because a template is like:"
        layerID="1" created="1290428439578" x="11793.822" y="2174.244"
        width="225.0" height="171.875" strokeWidth="1.0"
        autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b2a37f0001010b45ad3d2eb1871e</URIString>
        <child ID="2149" label="Template" created="1290428510175"
            x="34.0" y="53.0" width="230.0" height="150.5"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#ECFFD4</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7389b2a37f0001010b45ad3d2ffed3ed</URIString>
            <child ID="2150" label="asset_type | ONE | ASSETTYPE"
                created="1290428510175" x="34.0" y="23.0" width="183.0"
                height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
                <fillColor>#FDE888</fillColor>
                <strokeColor>#776D6D</strokeColor>
                <textColor>#000000</textColor>
                <font>Arial-plain-12</font>
                <metadata-list category-list-size="1"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                    <metadata xsi:type="vue-metadata-element">
                        <value></value>
                        <key>http://vue.tufts.edu/vue.rdfs#none</key>
                        <type>1</type>
                    </metadata>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/7389b2a37f0001010b45ad3da34391da</URIString>
                <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
            </child>
            <child ID="2151" label="pipeline_step | ONE | PIPELENSTEP"
                created="1290428510176" x="34.0" y="42.5" width="212.0"
                height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
                <fillColor>#FDE888</fillColor>
                <strokeColor>#776D6D</strokeColor>
                <textColor>#000000</textColor>
                <font>Arial-plain-12</font>
                <metadata-list category-list-size="1"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                    <metadata xsi:type="vue-metadata-element">
                        <value></value>
                        <key>http://vue.tufts.edu/vue.rdfs#none</key>
                        <type>1</type>
                    </metadata>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/7389b2a37f0001010b45ad3d5d01bd82</URIString>
                <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
            </child>
            <child ID="2152" label="template_code | UNICODE"
                created="1290428510176" x="34.0" y="62.0" width="158.0"
                height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
                <fillColor>#FDE888</fillColor>
                <strokeColor>#776D6D</strokeColor>
                <textColor>#000000</textColor>
                <font>Arial-plain-12</font>
                <metadata-list category-list-size="1"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                    <metadata xsi:type="vue-metadata-element">
                        <value></value>
                        <key>http://vue.tufts.edu/vue.rdfs#none</key>
                        <type>1</type>
                    </metadata>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/7389b2a47f0001010b45ad3dcbb17974</URIString>
                <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
            </child>
            <child ID="2153"
                label="Examples: {{projects.root}}/{{project.name}} /SEQUENCES/{{sequence.name}} /SHOTS/{{shot.name}}"
                created="1290428510176" x="34.0" y="81.5" width="191.0"
                height="63.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <metadata-list category-list-size="1"
                    other-list-size="0" ontology-list-size="0" RCategoryListSize="0">
                    <ontology-list-string></ontology-list-string>
                    <metadata xsi:type="vue-metadata-element">
                        <value></value>
                        <key>http://vue.tufts.edu/vue.rdfs#none</key>
                        <type>1</type>
                    </metadata>
                </metadata-list>
                <URIString>http://vue.tufts.edu/rdf/resource/7389b2a47f0001010b45ad3d91817f7f</URIString>
                <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Examples:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      {{projects.root}}/{{project.name}}
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      /SEQUENCES/{{sequence.name}}
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      /SHOTS/{{shot.name}}
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
                <label>Examples: {{projects.root}}/{{project.name}} /SEQUENCES/{{sequence.name}} /SHOTS/{{shot.name}}</label>
            </child>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2146" layerID="1" created="1290428439582" x="11905.822"
        y="2148.7444" width="1.0" height="25.999512" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b2a57f0001010b45ad3de520dce3</URIString>
        <point1 x="11906.322" y="2149.2444"/>
        <point2 x="11906.322" y="2174.244"/>
        <ID1 xsi:type="node">2143</ID1>
        <ID2 xsi:type="node">2145</ID2>
    </child>
    <child ID="2147" label="too much specialization" layerID="1"
        created="1290428484654" x="11833.822" y="2423.7102"
        width="145.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7389b2a57f0001010b45ad3dda5f0f57</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2154" label="Repository" layerID="1"
        created="1290429229074" x="9683.55" y="796.2019" width="156.75"
        height="140.75" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7394cf4e7f0001010b45ad3d4505f265</URIString>
        <child ID="2192" label="linux_path | UNICODE"
            created="1290433909826" x="34.0" y="23.0" width="132.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/73db9f4c7f0001010b45ad3de656431d</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2193" label="osx_path | UNICODE"
            created="1290433929378" x="34.0" y="43.25" width="126.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/73db9f4c7f0001010b45ad3dbced640d</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2194" label="windows_path | UNICODE"
            created="1290433937695" x="34.0" y="63.5" width="156.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#F2AE45</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/73db9f4c7f0001010b45ad3d456aaae7</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2197"
            label="path -> one of the path&#xa;above defined&#xa;according to the&#xa;current system"
            created="1290435168262" x="34.0" y="83.75" width="133.0"
            height="68.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#BDE5F2</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/73ee6ed37f0001010b45ad3d6434d46f</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="2157" layerID="1" created="1290429260559" x="9761.102"
        y="622.7656" width="742.1914" height="173.98438"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7394cf4e7f0001010b45ad3d9f393b4e</URIString>
        <point1 x="10502.793" y="623.2656"/>
        <point2 x="9761.602" y="796.25"/>
        <ID1 xsi:type="node">1887</ID1>
        <ID2 xsi:type="node">2154</ID2>
        <ctrlPoint0 x="10508.399" y="761.51984" xsi:type="point"/>
        <ctrlPoint1 x="9761.27" y="723.41925" xsi:type="point"/>
    </child>
    <child ID="2160"
        label="I want to be able to move the&#xa;localy selected files in to the&#xa;project"
        layerID="1" created="1290429671872" x="11889.611" y="1857.444"
        width="166.0" height="53.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/739c551d7f0001010b45ad3d8cc96286</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2161" layerID="1" created="1290429671877" x="11972.111"
        y="1827.0442" width="1.0" height="30.89978" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/739c551d7f0001010b45ad3d7e48d57e</URIString>
        <point1 x="11972.611" y="1827.5442"/>
        <point2 x="11972.611" y="1857.444"/>
        <ID1 xsi:type="node">2142</ID1>
        <ID2 xsi:type="node">2160</ID2>
    </child>
    <child ID="2162"
        label="so I need templates&#xa;to tell me where to&#xa;put the reference files"
        layerID="1" created="1290429695965" x="11908.111" y="1935.8439"
        width="129.0" height="53.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/739c551d7f0001010b45ad3d5a0a2c93</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2163" layerID="1" created="1290429695971" x="11972.111"
        y="1909.944" width="1.0" height="26.399902" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/739c551e7f0001010b45ad3d485244a7</URIString>
        <point1 x="11972.611" y="1910.444"/>
        <point2 x="11972.611" y="1935.8439"/>
        <ID1 xsi:type="node">2160</ID1>
        <ID2 xsi:type="node">2162</ID2>
    </child>
    <child ID="2167" label="where to save&#xa;the template information"
        layerID="1" created="1290429724283" x="11900.611" y="2015.8439"
        width="144.0" height="38.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/739c551e7f0001010b45ad3d4388adf9</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2168" layerID="1" created="1290429724287" x="11972.111"
        y="1988.3439" width="1.0" height="28.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/739c551e7f0001010b45ad3d829e5aec</URIString>
        <point1 x="11972.611" y="1988.8439"/>
        <point2 x="11972.611" y="2015.8439"/>
        <ID1 xsi:type="node">2162</ID1>
        <ID2 xsi:type="node">2167</ID2>
    </child>
    <child ID="2169" label="add another reference_templates column"
        layerID="1" created="1290429902656" x="11787.322" y="2377.4314"
        width="238.0" height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/739e1da67f0001010b45ad3dba5f91ba</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2175" layerID="1" created="1290429913998" x="11905.822"
        y="2345.619" width="1.0" height="32.3125" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/739e1da67f0001010b45ad3d81c3b80d</URIString>
        <point1 x="11906.322" y="2346.119"/>
        <point2 x="11906.322" y="2377.4314"/>
        <ID1 xsi:type="node">2145</ID1>
        <ID2 xsi:type="node">2169</ID2>
    </child>
    <child ID="2176" layerID="1" created="1290429916033" x="11905.822"
        y="2399.9314" width="1.0" height="24.278809" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/739e1da77f0001010b45ad3ddeae5d00</URIString>
        <point1 x="11906.322" y="2400.4314"/>
        <point2 x="11906.322" y="2423.7102"/>
        <ID1 xsi:type="node">2169</ID1>
        <ID2 xsi:type="node">2147</ID2>
    </child>
    <child ID="2177" label="template should be like this:" layerID="1"
        created="1290430092371" x="12141.985" y="1875.0436"
        width="434.0" height="41.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/73a89ec47f0001010b45ad3d3340d8ba</URIString>
        <child ID="2130"
            label="{{repository.path}}/{{project.code}}/REFS/{{entity.code}}/{{file.id}}_{{file.name}}"
            created="1290427988458" x="5.0" y="23.0" width="424.0"
            height="12.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/7389b2a17f0001010b45ad3dea542853</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      {{repository.path}}/{{project.code}}/REFS/{{entity.code}}/{{file.id}}_{{file.name}}
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>{{repository.path}}/{{project.code}}/REFS/{{entity.code}}/{{file.id}}_{{file.name}}</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2178" layerID="1" created="1290430092376" x="12066.111"
        y="1813.6975" width="219.69336" height="61.84619"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/73a89ec57f0001010b45ad3d5be80605</URIString>
        <point1 x="12066.611" y="1814.1975"/>
        <point2 x="12285.305" y="1875.0437"/>
        <ID1 xsi:type="node">2142</ID1>
        <ID2 xsi:type="node">2177</ID2>
    </child>
    <child ID="2179" label="Character" layerID="1"
        created="1290430311872" x="11755.649" y="2783.21" width="150.0"
        height="18.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/73a89ec57f0001010b45ad3db2c1b987</URIString>
        <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Character
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Character</label>
    </child>
    <child ID="2180" label="TypeTemplate" layerID="1"
        created="1290430525012" x="11099.047" y="796.225" width="150.75"
        height="86.75" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/73a89ec67f0001010b45ad3d49fb4e30</URIString>
        <child ID="2332" label="path_code| STRING"
            created="1293710778089" x="34.0" y="23.0" width="120.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/372d244c7f00010150882100fb860d9b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2331" label="file_code| STRING"
            created="1293710767892" x="34.0" y="43.25" width="112.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/372d244c7f000101508821007f113662</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2396" label="type | ONE | TYPEENTITY"
            created="1294153998161" x="34.0" y="63.5" width="148.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/519a2e2c7f0001017517e53bf0d1912b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2198" label="BUT!!!&#xa;REASONABLE ENOUGH" layerID="1"
        created="1290435474198" x="11836.322" y="2479.0437"
        width="140.0" height="38.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/73f32c657f0001010b45ad3de4631d2a</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2199" layerID="1" created="1290435474203" x="11905.822"
        y="2446.2102" width="1.0" height="33.333496" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/73f32c657f0001010b45ad3d5690194d</URIString>
        <point1 x="11906.322" y="2446.7102"/>
        <point2 x="11906.322" y="2479.0437"/>
        <ID1 xsi:type="node">2147</ID1>
        <ID2 xsi:type="node">2198</ID2>
    </child>
    <child ID="2203" label="Shows back -references" layerID="1"
        created="1290436660061" x="10725.871" y="283.12534"
        width="302.0" height="18.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/740838427f0001010b45ad3d5e0a73f3</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Shows back -references
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Shows back -references</label>
    </child>
    <child ID="2205"
        label="Shows secondary attributes which are derived from current attributes and &#xa;      are not persistet in the database"
        layerID="1" created="1290436660061" x="10725.871" y="313.1537"
        width="302.0" height="33.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/740838437f0001010b45ad3d8a55f990</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Shows secondary attributes which are derived from current attributes and 
      are not persistet in the database
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Shows secondary attributes which are derived from current attributes and 
      are not persistet in the database</label>
    </child>
    <child ID="2208"
        label="Shows nodes those are not going to be implemented"
        layerID="1" created="1290436767093" x="10725.871" y="347.1817"
        width="302.0" height="29.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/740838437f0001010b45ad3d5ec22072</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Shows nodes those are not going to be implemented
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Shows nodes those are not going to be implemented</label>
    </child>
    <child ID="2211"
        label="Shows attributes those are not going to be implemented"
        layerID="1" created="1290437154352" x="10725.871" y="374.70996"
        width="302.0" height="32.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/740cd0037f0001010b45ad3d146c4c2a</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Shows attributes those are not going to be implemented
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Shows attributes those are not going to be implemented</label>
    </child>
    <child ID="1813" layerID="1" created="1282128089956" x="10690.855"
        y="190.40186" width="26.299805" height="23.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/84ca7c987f00010138aea98153c19261</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="1818" layerID="1" created="1282128771399" x="10690.855"
        y="251.76364" width="26.299805" height="23.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#F2AE45</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/84d4ca357f00010138aea981c2362867</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2202" layerID="1" created="1290436660061" x="10690.855"
        y="283.12534" width="26.299805" height="23.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#DAA9FF</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/740838427f0001010b45ad3d613481d3</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2204" layerID="1" created="1290436660061" x="10690.855"
        y="313.1537" width="26.299805" height="23.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#BDE5F2</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/740838437f0001010b45ad3d6fcb50ca</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2209" layerID="1" created="1290436833398" x="10690.855"
        y="347.1817" width="26.299805" height="23.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#FC938D</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/740838447f0001010b45ad3df4e42c98</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2212" layerID="1" created="1290437154352" x="10690.855"
        y="379.20996" width="26.299805" height="23.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#FCDBD9</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/740cd0047f0001010b45ad3d90884f24</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2214" label="STILL COOKING IDEAS" layerID="1"
        created="1290437542596" x="11771.383" y="126.84357"
        width="305.667" height="102.66669" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#B5B995</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-18</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/7412d2a47f0001010b45ad3d0fe8838d</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2224" label="Mapper" layerID="1" created="1292274937082"
        x="8805.515" y="1157.3435" width="80.0" height="44.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce5597f00010177026e406428bc52</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2225" label="Tables" layerID="1" created="1292274943148"
        x="8821.515" y="1065.3435" width="76.0" height="38.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce55a7f00010177026e405b6f7397</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2227" label="Python&#xa;Object Model" layerID="1"
        created="1292274951125" x="8700.515" y="1070.3435" width="82.0"
        height="38.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce55b7f00010177026e40538d6e0a</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2228" layerID="1" created="1292274951919" x="8762.971"
        y="1107.8433" width="57.62207" height="49.99951"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce55c7f00010177026e404ac18180</URIString>
        <point1 x="8763.47" y="1108.3433"/>
        <point2 x="8820.092" y="1157.3428"/>
        <ID1 xsi:type="node">2227</ID1>
        <ID2 xsi:type="node">2224</ID2>
    </child>
    <child ID="2229" label="SessionMaker" layerID="1"
        created="1292274975500" x="8534.515" y="1022.34357"
        width="111.0" height="47.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce55d7f00010177026e40f5873189</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2230" label="engine" layerID="1" created="1292274983370"
        x="8694.715" y="863.34357" width="70.0" height="39.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce55e7f00010177026e4085954d8d</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2231" layerID="1" created="1292275116284" x="8609.655"
        y="901.84375" width="103.84766" height="121.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce55f7f00010177026e40305f270b</URIString>
        <point1 x="8713.003" y="902.34375"/>
        <point2 x="8610.155" y="1022.34375"/>
        <ID1 xsi:type="node">2230</ID1>
        <ID2 xsi:type="node">2229</ID2>
    </child>
    <child ID="2232" label="session" layerID="1" created="1292275126025"
        x="8659.015" y="1223.8435" width="79.5" height="50.5"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce5617f00010177026e40f6ef7cde</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2233" layerID="1" created="1292275126033" x="8602.089"
        y="1068.8438" width="83.666016" height="155.5" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce5627f00010177026e400796cc3f</URIString>
        <point1 x="8602.589" y="1069.3438"/>
        <point2 x="8685.255" y="1223.8438"/>
        <ID1 xsi:type="node">2229</ID1>
        <ID2 xsi:type="node">2232</ID2>
    </child>
    <child ID="2234" label="MetaData" layerID="1"
        created="1292275149153" x="8825.515" y="968.34357" width="81.0"
        height="43.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce5637f00010177026e4015495ed2</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2236" label="Database" layerID="1"
        created="1292275223829" x="8692.715" y="762.34357" width="74.0"
        height="45.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce5647f00010177026e406e92ee08</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2237" label="engine(database)" layerID="1"
        created="1292275229366" x="8681.715" y="806.84357" width="96.0"
        height="57.0" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce5657f00010177026e40a5e1ab26</URIString>
        <point1 x="8729.715" y="807.34357"/>
        <point2 x="8729.715" y="863.34357"/>
        <ID1 xsi:type="node">2236</ID1>
        <ID2 xsi:type="node">2230</ID2>
    </child>
    <child ID="2238" layerID="1" created="1292275242605" x="8860.321"
        y="1010.84375" width="4.7148438" height="55.007812"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce5667f00010177026e40a2f1c46f</URIString>
        <point1 x="8864.536" y="1011.34375"/>
        <point2 x="8860.821" y="1065.3516"/>
        <ID1 xsi:type="node">2234</ID1>
        <ID2 xsi:type="node">2225</ID2>
    </child>
    <child ID="2226" layerID="1" created="1292274944072" x="8848.258"
        y="1102.8398" width="8.958008" height="55.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce5677f00010177026e40fab7b7de</URIString>
        <point1 x="8856.715" y="1103.3398"/>
        <point2 x="8848.757" y="1157.3398"/>
        <ID1 xsi:type="node">2225</ID1>
        <ID2 xsi:type="node">2224</ID2>
    </child>
    <child ID="2242" label="metadata.create_all(engine)" layerID="1"
        created="1292275291662" x="8720.092" y="901.84375" width="153.0"
        height="67.0" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e19ce5687f00010177026e40d871ebc7</URIString>
        <point1 x="8754.555" y="902.34375"/>
        <point2 x="8838.628" y="968.34375"/>
        <ID1 xsi:type="node">2230</ID1>
        <ID2 xsi:type="node">2234</ID2>
    </child>
    <child ID="2249" label="add" layerID="1" created="1292275365435"
        x="8705.023" y="1107.8457" width="31.907227" height="116.49805"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e1a292207f00010177026e40616be0a9</URIString>
        <point1 x="8736.43" y="1108.3457"/>
        <point2 x="8705.522" y="1223.8438"/>
        <ID1 xsi:type="node">2227</ID1>
        <ID2 xsi:type="node">2232</ID2>
    </child>
    <child ID="2250" label="Persisting" layerID="1"
        created="1292275372356" x="8419.607" y="786.22815"
        width="273.60742" height="480.49915" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e1a292217f00010177026e4079dd75c1</URIString>
        <point1 x="8659.015" y="1260.449"/>
        <point2 x="8692.715" y="786.72815"/>
        <ID1 xsi:type="node">2232</ID1>
        <ID2 xsi:type="node">2236</ID2>
        <ctrlPoint0 x="8427.736" y="1326.519" xsi:type="point"/>
        <ctrlPoint1 x="8316.64" y="805.8836" xsi:type="point"/>
    </child>
    <child ID="2254" label="config&#xa;(environment&#xa;variables)"
        layerID="1" created="1292275586156" x="8688.215" y="601.34357"
        width="83.0" height="53.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e1a292227f00010177026e40f20f40e8</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2255" label="database_adress&#xa;&amp;&#xa;user_name"
        layerID="1" created="1292275586704" x="8682.215" y="653.84357"
        width="95.0" height="109.0" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e1a292227f00010177026e404f21e562</URIString>
        <point1 x="8729.715" y="654.34357"/>
        <point2 x="8729.715" y="762.34357"/>
        <ID1 xsi:type="node">2254</ID1>
        <ID2 xsi:type="node">2236</ID2>
    </child>
    <child ID="2257" label="SQLALCHEMY DB SETUP" layerID="1"
        created="1292277139230" x="8565.715" y="470.34357" width="328.0"
        height="87.0" strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#DAA9FF</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-18</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/e1b958057f00010177026e4065f7dcfe</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2267" layerID="1" created="1292744499011" x="10354.422"
        y="450.8789" width="127.296875" height="127.49609"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/ff73db6b7f0001015481be8a2537d4ab</URIString>
        <point1 x="10481.219" y="451.3789"/>
        <point2 x="10354.922" y="577.875"/>
        <ID1 xsi:type="node">1901</ID1>
        <ID2 xsi:type="node">1295</ID2>
        <ctrlPoint0 x="10458.188" y="567.40485" xsi:type="point"/>
        <ctrlPoint1 x="10360.736" y="501.87897" xsi:type="point"/>
    </child>
    <child ID="1900" layerID="1" created="1288257142624" x="10480.418"
        y="450.8789" width="24.623047" height="126.62109"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/f21c2a7b7f0001010d9438ded95282fa</URIString>
        <point1 x="10483.227" y="451.3789"/>
        <point2 x="10503.976" y="577.0"/>
        <ID1 xsi:type="node">1901</ID1>
        <ID2 xsi:type="node">1887</ID2>
        <ctrlPoint0 x="10471.109" y="522.1249" xsi:type="point"/>
        <ctrlPoint1 x="10510.782" y="502.7901" xsi:type="point"/>
    </child>
    <child ID="2287" label="Hold in Structure" layerID="1"
        created="1293638447932" x="13135.107" y="844.37695"
        width="241.0" height="173.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#30D643</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/32deba3f7f0001015088210050d1939f</URIString>
        <child ID="2288"
            label="Generalize the structure system and add: folder_templates asset_templates reference_templates to hold templates for every one of them. This leads us a complete structure object where one can see the whole picture in one object..."
            created="1293638447932" x="5.0" y="23.0" width="231.0"
            height="144.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/32deba3f7f000101508821006c2d59f4</URIString>
            <richText>&lt;html&gt;
  &lt;head&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Generalize the structure system and add:
    &lt;/p&gt;
    &lt;ul color="#000000"&gt;
      &lt;li style="color: #000000" color="#000000"&gt;
        folder_templates
      &lt;/li&gt;
      &lt;li style="color: #000000" color="#000000"&gt;
        asset_templates
      &lt;/li&gt;
      &lt;li style="color: #000000" color="#000000"&gt;
        reference_templates
      &lt;/li&gt;
    &lt;/ul&gt;
    &lt;p color="#000000"&gt;
      
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      to hold templates for every one of them. This leads us a complete 
      structure object where one can see the whole picture in one object...
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Generalize the structure system and add: folder_templates asset_templates reference_templates to hold templates for every one of them. This leads us a complete structure object where one can see the whole picture in one object...</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2289" label="SOLUTION 3&#xa;THE BEST SOLUTION"
        layerID="1" created="1293638451191" x="12919.361" y="670.71094"
        width="226.10352" height="175.39746" strokeWidth="3.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/32deba407f00010150882100a056b737</URIString>
        <point1 x="12920.861" y="672.21094"/>
        <point2 x="13143.965" y="844.6084"/>
        <ID1 xsi:type="node">2026</ID1>
        <ID2 xsi:type="node">2287</ID2>
    </child>
    <child ID="2301" label="LinkType" layerID="1"
        created="1293639905701" x="11323.357" y="973.225" width="104.0"
        height="137.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/32f3ce3d7f00010150882100703f1ea6</URIString>
        <child ID="2305"
            label="Examples: Image ImageSequence Video Text Web ..."
            created="1293639905702" x="5.0" y="23.0" width="94.0"
            height="108.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/32f3ce3d7f000101508821003b9a78db</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Examples:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Image
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      ImageSequence
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Video
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Text
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Web
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      ...
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Examples: Image ImageSequence Video Text Web ...</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2308" layerID="1" created="1293640235539" x="11330.5"
        y="820.75" width="46.411133" height="153.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/32f819747f00010150882100cc0a56de</URIString>
        <point1 x="11331.0" y="821.25"/>
        <point2 x="11376.411" y="973.25"/>
        <ID1 xsi:type="node">2397</ID1>
        <ID2 xsi:type="node">2301</ID2>
        <ctrlPoint0 x="11329.832" y="907.0903" xsi:type="point"/>
        <ctrlPoint1 x="11377.462" y="904.96027" xsi:type="point"/>
    </child>
    <child ID="2319" label="version" layerID="1" created="1293706572638"
        x="12419.274" y="1489.2103" width="93.0" height="29.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/370c82157f00010150882100318ba225</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2321" label="version.task" layerID="1"
        created="1293706577144" x="12430.121" y="1517.6875" width="69.0"
        height="82.1875" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/370c82167f00010150882100fbc03f47</URIString>
        <point1 x="12465.471" y="1518.1875"/>
        <point2 x="12463.7705" y="1599.375"/>
        <ID1 xsi:type="node">2319</ID1>
        <ID2 xsi:type="node">2322</ID2>
    </child>
    <child ID="2322" label="task" layerID="1" created="1293706587561"
        x="12419.774" y="1599.377" width="87.5" height="23.5"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/370c82167f00010150882100c967ecd4</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2324" label="pipelineStep" layerID="1"
        created="1293706642673" x="12315.108" y="1716.377" width="80.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/370c82167f00010150882100be8598dc</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2325" label="task.pipeline_step" layerID="1"
        created="1293706642678" x="12358.199" y="1622.377" width="102.0"
        height="94.5" strokeWidth="1.0" autoSized="false"
        controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/370c82167f000101508821004c57c340</URIString>
        <point1 x="12452.612" y="1622.877"/>
        <point2 x="12365.787" y="1716.377"/>
        <ID1 xsi:type="node">2322</ID1>
        <ID2 xsi:type="node">2324</ID2>
    </child>
    <child ID="2328" label="assetBase" layerID="1"
        created="1293706765117" x="12559.774" y="1733.7102" width="71.0"
        height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/370c82167f000101508821000ce84590</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2329" label="parent_asset" layerID="1"
        created="1293706765122" x="12474.57" y="1622.377"
        width="109.9043" height="111.83301" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/370c82167f000101508821004cd5726c</URIString>
        <point1 x="12475.07" y="1622.877"/>
        <point2 x="12583.975" y="1733.71"/>
        <ID1 xsi:type="node">2322</ID1>
        <ID2 xsi:type="node">2328</ID2>
    </child>
    <child ID="2333" label="AssetTemplate" layerID="1"
        created="1293717259136" x="12364.389" y="51.83545" width="177.0"
        height="46.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/378f410b7f00010150882100d07ef254</URIString>
        <child ID="2369" label="asset_type | ONE | ASSETTYPE"
            created="1293721259644" x="34.0" y="23.0" width="183.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/37cc22ee7f00010150882100864e6ffb</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2358" label="ReferenceTemplate" layerID="1"
        created="1293717927562" x="12422.276" y="-9.164551"
        width="220.5" height="46.25" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/379966d07f000101508821000b2bd7fd</URIString>
        <child ID="2359" label="reference_type | ONE | REFERENCETYPE"
            created="1293717927562" x="34.0" y="23.0" width="241.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/379966d07f0001015088210028a2ff79</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2364" label="IDEA" layerID="1" created="1293718250408"
        x="11641.208" y="546.71027" width="214.0" height="107.0"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#83CEFF</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/37a30c927f00010150882100f79e8e1f</URIString>
        <child ID="2366"
            label="if move_to_project selected (the default option) the linked reference &#xa;      will be moved to project by looking at the reference templates of the project structure"
            created="1293718258631" x="5.0" y="23.0" width="204.0"
            height="78.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/37a30c927f000101508821006036ce9d</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      if move_to_project selected (the default option) the linked reference 
      will be moved to project by looking at the reference templates of the 
      project structure
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>if move_to_project selected (the default option) the linked reference 
      will be moved to project by looking at the reference templates of the project structure</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2365" layerID="1" created="1293718250413" x="11692.719"
        y="653.2031" width="59.666016" height="143.79688"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/37a30c937f000101508821001ba66b40</URIString>
        <point1 x="11693.219" y="796.5"/>
        <point2 x="11751.671" y="653.7031"/>
        <ID1 xsi:type="node">1145</ID1>
        <ID2 xsi:type="node">2364</ID2>
        <ctrlPoint0 x="11692.986" y="719.52386" xsi:type="point"/>
        <ctrlPoint1 x="11756.966" y="735.4827" xsi:type="point"/>
    </child>
    <child ID="2374" label="Shows implemented classes with persistancy"
        layerID="1" created="1294147396477" x="10725.871" y="221.37695"
        width="261.0" height="18.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/51327de87f0001017517e53b4e0b6faa</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Shows implemented classes with persistancy
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Shows implemented classes with persistancy</label>
    </child>
    <child ID="2375" layerID="1" created="1294147396477" x="10690.855"
        y="221.37695" width="26.299805" height="23.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/51327de87f0001017517e53b06dcb343</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="2379" label="FileSequence" layerID="1"
        created="1294150177342" x="12463.344" y="304.57715"
        width="115.0" height="66.5" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/5161bffb7f0001017517e53b94128c41</URIString>
        <child ID="2380" label="start | INTEGER" created="1294150177342"
            x="34.0" y="23.0" width="97.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/5161bffb7f0001017517e53b3481e15b</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <child ID="2381" label="end | INTEGER" created="1294150177342"
            x="34.0" y="43.25" width="94.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/5161bffc7f0001017517e53b06eb0375</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2382" label="File" layerID="1" created="1294150177342"
        x="12305.38" y="304.9524" width="128.25" height="46.25"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/5161bffc7f0001017517e53b0a74a25b</URIString>
        <child ID="2383" label="file_size | INTEGER"
            created="1294150177342" x="34.0" y="23.0" width="118.0"
            height="23.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/5161bffc7f0001017517e53bfcda26b7</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2384" layerID="1" created="1294150177342" x="12460.803"
        y="124.67676" width="61.476562" height="180.38574"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/5161bffc7f0001017517e53b1d3dd4c2</URIString>
        <point1 x="12461.303" y="125.17676"/>
        <point2 x="12521.779" y="304.5625"/>
        <ID2 xsi:type="node">2379</ID2>
        <ctrlPoint0 x="12466.923" y="290.18054" xsi:type="point"/>
        <ctrlPoint1 x="12523.488" y="243.80017" xsi:type="point"/>
    </child>
    <child ID="2385" layerID="1" created="1294150177342" x="12369.27"
        y="124.67676" width="92.475586" height="180.82324"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/5161bffc7f0001017517e53b0c1d6699</URIString>
        <point1 x="12461.245" y="125.17676"/>
        <point2 x="12369.77" y="305.0"/>
        <ID2 xsi:type="node">2382</ID2>
        <ctrlPoint0 x="12466.6" y="290.77173" xsi:type="point"/>
        <ctrlPoint1 x="12370.3955" y="250.06305" xsi:type="point"/>
    </child>
    <child ID="2386" label="Folder" layerID="1" created="1294150177342"
        x="12229.92" y="304.9524" width="46.0" height="23.0"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/5161bffd7f0001017517e53b80768083</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2387" layerID="1" created="1294150177342" x="12252.456"
        y="124.67676" width="209.29492" height="180.82324"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/5161bffd7f0001017517e53b94d526a0</URIString>
        <point1 x="12461.251" y="125.17676"/>
        <point2 x="12252.956" y="305.0"/>
        <ID2 xsi:type="node">2386</ID2>
        <ctrlPoint0 x="12466.551" y="288.1317" xsi:type="point"/>
        <ctrlPoint1 x="12253.15" y="243.85834" xsi:type="point"/>
    </child>
    <child ID="2388" label="Web" layerID="1" created="1294150177342"
        x="12608.045" y="304.57715" width="107.25" height="46.25"
        strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#ECFFD4</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/5161bffd7f0001017517e53b87414322</URIString>
        <child ID="2389" label="url | UNICODE" created="1294150177343"
            x="34.0" y="23.0" width="90.0" height="23.0"
            strokeWidth="1.0" autoSized="true" xsi:type="node">
            <fillColor>#FDE888</fillColor>
            <strokeColor>#776D6D</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/5161bffd7f0001017517e53bf8dd37fb</URIString>
            <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2390" layerID="1" created="1294150177342" x="12460.773"
        y="124.67676" width="202.06055" height="180.38574"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/5161bffd7f0001017517e53b5ed7b8f6</URIString>
        <point1 x="12461.273" y="125.17676"/>
        <point2 x="12662.334" y="304.5625"/>
        <ID2 xsi:type="node">2388</ID2>
        <ctrlPoint0 x="12466.568" y="284.7705" xsi:type="point"/>
        <ctrlPoint1 x="12664.098" y="243.01947" xsi:type="point"/>
    </child>
    <child ID="2397" label="TypeEntity" layerID="1"
        created="1294154217183" x="11279.732" y="796.225"
        width="102.875" height="25.0" strokeWidth="1.0"
        autoSized="false" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/519d2c637f0001017517e53b1a4782a4</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2400" layerID="1" created="1294154236073" x="11205.348"
        y="820.75" width="126.15918" height="153.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/519d2c637f0001017517e53b1dd28037</URIString>
        <point1 x="11331.007" y="821.25"/>
        <point2 x="11205.848" y="973.25"/>
        <ID1 xsi:type="node">2397</ID1>
        <ID2 xsi:type="node">1374</ID2>
        <ctrlPoint0 x="11329.88" y="907.441" xsi:type="point"/>
        <ctrlPoint1 x="11205.251" y="895.4908" xsi:type="point"/>
    </child>
    <child ID="2402" label="ProjectType" layerID="1"
        created="1294154324356" x="11457.107" y="973.225" width="81.0"
        height="107.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#9DDB53</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/519d2c637f0001017517e53b607c9d19</URIString>
        <child ID="2403" label="Examples: Commercial Movie Still ..."
            created="1294154324356" x="5.0" y="23.0" width="71.0"
            height="78.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/519d2c647f0001017517e53b19274f95</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Examples:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Commercial
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Movie
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Still
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      ...
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Examples: Commercial Movie Still ...</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2404" layerID="1" created="1294154354307" x="11330.537"
        y="820.75" width="168.41211" height="153.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/519d2c647f0001017517e53bec17ce13</URIString>
        <point1 x="11331.037" y="821.25"/>
        <point2 x="11498.449" y="973.25"/>
        <ID1 xsi:type="node">2397</ID1>
        <ID2 xsi:type="node">2402</ID2>
        <ctrlPoint0 x="11330.124" y="907.00714" xsi:type="point"/>
        <ctrlPoint1 x="11499.562" y="902.5341" xsi:type="point"/>
    </child>
    <child ID="2405" label="UserType" layerID="1"
        created="1294154384750" x="11568.107" y="973.225" width="73.0"
        height="107.0" strokeWidth="1.0" autoSized="true" xsi:type="node">
        <fillColor>#FC938D</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-12</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/519d2c647f0001017517e53b11a29d5c</URIString>
        <child ID="2406" label="Examples: SuperUser Admin Normal ..."
            created="1294154384750" x="5.0" y="23.0" width="63.0"
            height="78.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
            <fillColor>#FCDBD9</fillColor>
            <strokeColor>#404040</strokeColor>
            <textColor>#000000</textColor>
            <font>Arial-plain-12</font>
            <metadata-list category-list-size="1" other-list-size="0"
                ontology-list-size="0" RCategoryListSize="0">
                <ontology-list-string></ontology-list-string>
                <metadata xsi:type="vue-metadata-element">
                    <value></value>
                    <key>http://vue.tufts.edu/vue.rdfs#none</key>
                    <type>1</type>
                </metadata>
            </metadata-list>
            <URIString>http://vue.tufts.edu/rdf/resource/519d2c647f0001017517e53b912c4954</URIString>
            <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Examples:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      SuperUser
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Admin
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Normal
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      ...
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
            <label>Examples: SuperUser Admin Normal ...</label>
        </child>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2407" layerID="1" created="1294154418180" x="11330.502"
        y="820.75" width="274.98828" height="153.0" strokeWidth="1.0"
        autoSized="false" controlCount="2" arrowState="2" xsi:type="link">
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-11</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/51a470107f0001017517e53be075fac9</URIString>
        <point1 x="11331.002" y="821.25"/>
        <point2 x="11604.99" y="973.25"/>
        <ID1 xsi:type="node">2397</ID1>
        <ID2 xsi:type="node">2405</ID2>
        <ctrlPoint0 x="11329.848" y="907.1916" xsi:type="point"/>
        <ctrlPoint1 x="11605.54" y="896.62555" xsi:type="point"/>
    </child>
    <child ID="2363"
        label="Reference Template Example 1: ReferenceType = Image {{repository.path}}/{{project.code}}/REFS/{{reference.type.name}}/{{reference.link.name}}"
        layerID="1" created="1293717968929" x="11320.389" y="1247.0854"
        width="480.0" height="48.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/379ae6b47f00010150882100c2142256</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Reference Template Example 1:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      ReferenceType = Image
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      {{repository.path}}/{{project.code}}/REFS/{{reference.type.name}}/{{reference.link.name}}
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Reference Template Example 1: ReferenceType = Image {{repository.path}}/{{project.code}}/REFS/{{reference.type.name}}/{{reference.link.name}}</label>
    </child>
    <child ID="2338"
        label="Asset Version Template Example 1: AssetType.name = Shot {{repository.path}}/{{project.code}}/SEQUENCES/{{sequence.name}}/SHOTS/{{shot.code}}/{{pipeline_step.code}}/{{shot.code}}_{{take.name}}_{{version.version_number}}"
        layerID="1" created="1293717259137" x="11320.389" y="1135.0854"
        width="925.0" height="48.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/378f410b7f0001015088210053e34b34</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Asset Version Template Example 1:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      AssetType.name = Shot
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      {{repository.path}}/{{project.code}}/SEQUENCES/{{sequence.name}}/SHOTS/{{shot.code}}/{{pipeline_step.code}}/{{shot.code}}_{{take.name}}_{{version.version_number}}
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Asset Version Template Example 1: AssetType.name = Shot {{repository.path}}/{{project.code}}/SEQUENCES/{{sequence.name}}/SHOTS/{{shot.code}}/{{pipeline_step.code}}/{{shot.code}}_{{take.name}}_{{version.version_number}}</label>
    </child>
    <child ID="2408" label="TRASH" layerID="1" created="1294155278342"
        x="12359.773" y="-138.45639" width="305.667" height="102.66669"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#B5B995</fillColor>
        <strokeColor>#776D6D</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-bold-18</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/51aaed357f0001017517e53b20cfc539</URIString>
        <shape arcwidth="20.0" archeight="20.0" xsi:type="roundRect"/>
    </child>
    <child ID="2409"
        label="Asset Version Template Example 2: AssetType.name = Character {{repository.path}}/{{project.code}}/ASSETS/{{asset_type.name}}/{{pipeline_step.code}}/{{asset.name}}_{{take.name}}_{{asset_type.name}}_{{version.version_number}}"
        layerID="1" created="1294155909846" x="11320.389" y="1191.0436"
        width="962.0" height="48.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/51b7d1837f0001017517e53b679d9674</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Asset Version Template Example 2:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      AssetType.name = Character
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      {{repository.path}}/{{project.code}}/ASSETS/{{asset_type.name}}/{{pipeline_step.code}}/{{asset.name}}_{{take.name}}_{{asset_type.name}}_{{version.version_number}}
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Asset Version Template Example 2: AssetType.name = Character {{repository.path}}/{{project.code}}/ASSETS/{{asset_type.name}}/{{pipeline_step.code}}/{{asset.name}}_{{take.name}}_{{asset_type.name}}_{{version.version_number}}</label>
    </child>
    <child ID="2413"
        label="Reference Template Example 2: ReferenceType = Web (the same with the Image example) {{repository.path}}/{{project.code}}/REFS/{{reference.type.name}}/{{reference.link.name}}"
        layerID="1" created="1294156830278" x="11320.389" y="1301.0436"
        width="480.0" height="48.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <metadata-list category-list-size="1" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
            <metadata xsi:type="vue-metadata-element">
                <value></value>
                <key>http://vue.tufts.edu/vue.rdfs#none</key>
                <type>1</type>
            </metadata>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/51c2b1ad7f0001017517e53b94d0c271</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { font-family: Arial; margin-bottom: 0px; margin-right: 0px; font-size: 12; color: #000000; margin-top: 0px; margin-left: 0px }
        ol { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
        p { margin-bottom: 0; margin-right: 0; color: #000000; margin-top: 0; margin-left: 0 }
        ul { font-family: Arial; vertical-align: middle; font-size: 12; list-style-position: outside; margin-top: 6; margin-left: 30 }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Reference Template Example 2:
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      ReferenceType = Web (the same with the Image example)
    &lt;/p&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      {{repository.path}}/{{project.code}}/REFS/{{reference.type.name}}/{{reference.link.name}}
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Reference Template Example 2: ReferenceType = Web (the same with the Image example) {{repository.path}}/{{project.code}}/REFS/{{reference.type.name}}/{{reference.link.name}}</label>
    </child>
    <layer ID="1" label="Layer 1" created="0" x="0.0" y="0.0"
        width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <metadata-list category-list-size="0" other-list-size="0"
            ontology-list-size="0" RCategoryListSize="0">
            <ontology-list-string></ontology-list-string>
        </metadata-list>
        <URIString>http://vue.tufts.edu/rdf/resource/5d104b32c00007d601b277f026b72230</URIString>
    </layer>
    <userZoom>1.0</userZoom>
    <userOrigin x="8218.607" y="-150.95639"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="-1" revealerIndex="-1"/>
    <date>2009-05-20</date>
    <mapFilterModel/>
    <modelVersion>5</modelVersion>
    <saveLocation>/home/ozgur/Documents/development/stalker/docs/source/_static</saveLocation>
    <saveFile>/home/ozgur/Documents/development/stalker/docs/source/_static/stalker_design.vue</saveFile>
</LW-MAP>
